/*
 * Copyright 2019 Virscient Limited - All Rights Reserved
 *
 * Unauthorised copying of this software in binary or source code form
 * via any medium is strictly prohibited. This software is proprietary
 * and confidential.
 *
 * For more information, email info@virscient.com
 */

#include <kalimba.h>
#include <kalimba_standard_messages.h>
#include <file.h>
#include <micbias.h>
#include <string.h>
#include <panic.h>
#include <pio.h>
#include <source.h>
#include <sink.h>
#include <stream.h>
#include <led.h>
#include <connection.h>
#include <stdio.h>

/* Note: if enabling debug make sure a Babel is connected! */
#define DEBUG_ENABLEDx

#ifdef DEBUG_ENABLED
#define LOG_DEBUG(x) printf x
#else
#define LOG_DEBUG(x) do { } while (0)
#endif


/* Define the macro "BYPASS_KALIMBA" to bypass Kalimba DSP otherwise direct I2S->I2S */
#define BYPASS_KALIMBA

/* I2S Master / Slave switch. 1 = Master, 0 = Slave */
#define I2S_MASTER       1

/* I2S Interface frame rate*/
#define I2S_RATE     24000

/* Audio Bit Depth for use with the STREAM_AUDIO_SAMPLE_SIZE key */
#define BIT_DEPTH       32

/* Location of DSP kap file in the file system */
static const char kal[] = "my_first_24bit_dsp_app_kalimba/my_first_24bit_dsp_app_kalimba.kap";


/* Select Amp PIO depending on board used.  If not defined, assume the CNS10001v4 board is assumed. */
#ifdef H13179V2
    #define POWER_AMP_PIO 14
#else  /* Assume CNS10001v4 */
    #define POWER_AMP_PIO 4
#endif
#define MIC_INPUT


static void PioSetPio (uint16 pPIO, bool pOnOrOff)
{
    uint32_t pin = (1ul << pPIO);
    uint32_t val = pOnOrOff ? pin : 0;

    /* Set pin as output and set appropriate value. */
    PioSetDir32(pin, pin);
    PioSet32(pin, val);
}

typedef void (*callback_t)(void);


static unsigned trigger_pio = 7;
static unsigned addr = 0x0E;

#define PIO_BUTTON_MASK (uint32_t)((1ul<<13)|(1ul<<12)|(1ul<<11))
#define PIO_ADDR_MASK   (uint32_t)((1ul<<15)|(1ul<<14)|(1ul<<10)|(1ul<<8))

static void
pio_interface_task_handler(Task t, MessageId id, Message payload);

TaskData pio_task = { pio_interface_task_handler };

static bool input_mode_enabled = FALSE;

static void
process_buttons(void)
{
    static unsigned cnt = 0;
    static uint32_t old_pio_bits = 0;
    uint32_t pio_bits = PioGet32() & PIO_BUTTON_MASK;
    uint32_t pio_delta = pio_bits ^ old_pio_bits;
    uint32_t pio_rising = pio_delta & pio_bits;
    old_pio_bits = pio_bits;

    trigger_pio = 0;

    if (pio_delta != 0)
        LOG_DEBUG(("PIO delta: 0x%04lx, bits: 0x%04lx, rising: %04lx\n",
                   pio_delta, pio_bits, pio_rising));

    if (((++cnt & 0xF) == 0) && input_mode_enabled)
    {
        LOG_DEBUG(("Pairing status: %s\n",
                   (PioGet32() & (1<<8)) ? "done" : "active"));
    }

    if (pio_rising & (1<<12))
    {
        trigger_pio = 6;
        addr = 0x04;
    }
    else if (pio_rising & (1<<11))
    {
        if (!input_mode_enabled)
        {
            addr = 0x0F;
            trigger_pio = 6;
            input_mode_enabled = TRUE;
        }
        else
        {
            addr = 0x00;
            trigger_pio = 7;
            input_mode_enabled = FALSE;
        }
    }
    else if (pio_rising & (1<<13))
    {
        trigger_pio = 6;
        addr = 0x0E;
    }

    if (trigger_pio != 0)
    {
        LOG_DEBUG(("Sending command 0x%04x PIO%d (input_mode=%d)\n",
                   addr, trigger_pio, input_mode_enabled));
        PioSetPio(8,  (addr & 0x01) ? TRUE : FALSE);
        PioSetPio(10, (addr & 0x02) ? TRUE : FALSE);
        PioSetPio(14, (addr & 0x04) ? TRUE : FALSE);
        PioSetPio(15, (addr & 0x08) ? TRUE : FALSE);

        PioSetPio(trigger_pio, TRUE);

        MessageSendLater(&pio_task, 1, 0, 30);
    }
}

static void
pio_interface_task_handler(Task t, MessageId id, Message payload)
{
    switch (id)
    {
    case 1:
        PioSetPio(6, FALSE);
        PioSetPio(7, FALSE);

        /* If we have entered "input" mode (i.e., we have just sent command
         * 0xF then we set the address pins as inputs. */
        if (input_mode_enabled)
        {
            uint32_t pio_addr_mask = PIO_ADDR_MASK;
            PioSetDir32(pio_addr_mask, 0x00);
        }
        break;

    case 2:
        process_buttons();
        MessageSendLater(&pio_task, 2, 0, 10);
        break;
    }
}


static void
pio_test(void)
{
    PioSet32(PIO_BUTTON_MASK,0);
    MessageSendLater(&pio_task, 2, 0, 1000);
}


void start_kalimba(void);
void connect_streams(void);
void led(void);

/* Main VM routine */
int main(void)
{
    /* Connect up audio ports */
    connect_streams();

    /* Turn on LED */
    led();

    pio_test();

    /* Remain in MessageLoop (handles messages) */
    MessageLoop();

    return 0;
}


void connect_streams(void)
{
    /* Audio Interfaces */
    Source I2S_IN_0;
    Source I2S_IN_1;

    Sink I2S_OUT_0;
    Sink I2S_OUT_1;

        /* Access left and right ADC and DAC */
    Source audio_source_a = StreamAudioSource( AUDIO_HARDWARE_CODEC, AUDIO_INSTANCE_0, AUDIO_CHANNEL_A );
    Source audio_source_b = StreamAudioSource( AUDIO_HARDWARE_CODEC, AUDIO_INSTANCE_0, AUDIO_CHANNEL_B );
    Sink audio_sink_a = StreamAudioSink( AUDIO_HARDWARE_CODEC, AUDIO_INSTANCE_0, AUDIO_CHANNEL_A );
    Sink audio_sink_b = StreamAudioSink( AUDIO_HARDWARE_CODEC, AUDIO_INSTANCE_0, AUDIO_CHANNEL_B );

    /* Configure sampling rate for both channels and synchronise left and right channels */
    PanicFalse( SourceConfigure(audio_source_a, STREAM_CODEC_INPUT_RATE, I2S_RATE) );
    PanicFalse( SourceConfigure(audio_source_b, STREAM_CODEC_INPUT_RATE, I2S_RATE) );
    PanicFalse( SourceSynchronise(audio_source_a, audio_source_b) );

    PanicFalse( SinkConfigure(audio_sink_a, STREAM_CODEC_OUTPUT_RATE, I2S_RATE) );
    PanicFalse( SinkConfigure(audio_sink_b, STREAM_CODEC_OUTPUT_RATE, I2S_RATE) );
    PanicFalse( SinkSynchronise(audio_sink_a, audio_sink_b) );

    /* Set up codec gains */
#ifdef MIC_INPUT
    PanicFalse( SourceConfigure(audio_source_a, STREAM_CODEC_MIC_INPUT_GAIN_ENABLE, 1) );
    PanicFalse( SourceConfigure(audio_source_b, STREAM_CODEC_MIC_INPUT_GAIN_ENABLE, 1) );

    PanicFalse(MicbiasConfigure(MIC_BIAS_0, MIC_BIAS_ENABLE, MIC_BIAS_FORCE_ON));
    PanicFalse(MicbiasConfigure(MIC_BIAS_1, MIC_BIAS_ENABLE, MIC_BIAS_FORCE_ON));
#else
    PanicFalse( SourceConfigure(audio_source_a, STREAM_CODEC_MIC_INPUT_GAIN_ENABLE, 0) );
    PanicFalse( SourceConfigure(audio_source_b, STREAM_CODEC_MIC_INPUT_GAIN_ENABLE, 0) );
#endif

    PanicFalse( SourceConfigure(audio_source_a, STREAM_CODEC_INPUT_GAIN, 6) );
    PanicFalse( SourceConfigure(audio_source_b, STREAM_CODEC_INPUT_GAIN, 6) );

    PioSetPio(POWER_AMP_PIO, TRUE);

    PanicFalse( SinkConfigure(audio_sink_a, STREAM_CODEC_OUTPUT_GAIN, 15) );
    PanicFalse( SinkConfigure(audio_sink_b, STREAM_CODEC_OUTPUT_GAIN, 15) );

    /* I2S Setup */

    /* Source StreamAudioSource (audio_hardware hardware, audio_instance instance, audio_channel channel); */
    I2S_IN_0 = StreamAudioSource(AUDIO_HARDWARE_I2S, AUDIO_INSTANCE_0, AUDIO_CHANNEL_SLOT_0);
    I2S_IN_1 = StreamAudioSource(AUDIO_HARDWARE_I2S, AUDIO_INSTANCE_0, AUDIO_CHANNEL_SLOT_1);

    /* Sink StreamAudioSink (audio_hardware hardware, audio_instance instance, audio_channel channel); */
    I2S_OUT_0 = StreamAudioSink(AUDIO_HARDWARE_I2S, AUDIO_INSTANCE_0, AUDIO_CHANNEL_SLOT_0);
    I2S_OUT_1 = StreamAudioSink(AUDIO_HARDWARE_I2S, AUDIO_INSTANCE_0, AUDIO_CHANNEL_SLOT_1);

    /* SinkConfigure (Sink sink, stream_config_key key, uint32 value) */
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_MASTER_MODE, I2S_MASTER));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_MASTER_MODE, I2S_MASTER));
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_SYNC_RATE, I2S_RATE));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_SYNC_RATE, I2S_RATE));

    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_MASTER_CLOCK_RATE, 0));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_MASTER_CLOCK_RATE, 0));
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_JSTFY_FORMAT, 0));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_JSTFY_FORMAT, 0));
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_LFT_JSTFY_DLY, 1));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_LFT_JSTFY_DLY, 1));
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_CHNL_PLRTY, 1));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_CHNL_PLRTY, 1));
    PanicFalse(SinkConfigure(I2S_OUT_0, STREAM_I2S_BITS_PER_SAMPLE, BIT_DEPTH));
    PanicFalse(SinkConfigure(I2S_OUT_1, STREAM_I2S_BITS_PER_SAMPLE, BIT_DEPTH));

    /* SourceConfigure (Source source, stream_config_key key, uint32 value) */
    PanicFalse(SourceConfigure(I2S_IN_0, STREAM_I2S_SYNC_RATE, I2S_RATE));
    PanicFalse(SourceConfigure(I2S_IN_1, STREAM_I2S_SYNC_RATE, I2S_RATE));

    /* Synchronise sink and source*/
    PanicFalse(SinkSynchronise(I2S_OUT_0, I2S_OUT_1));
    PanicFalse(SourceSynchronise(I2S_IN_0, I2S_IN_1));

#ifndef LOOPBACK
    PanicFalse( StreamConnect(I2S_IN_0, audio_sink_a) );
    PanicFalse( StreamConnect(audio_source_a, I2S_OUT_0) );
    PanicFalse( StreamConnect(I2S_IN_1, audio_sink_b) );
    PanicFalse( StreamConnect(audio_source_b, I2S_OUT_1) );
#else
    PanicFalse( StreamConnect(I2S_IN_0, I2S_OUT_0) );
    PanicFalse( StreamConnect(I2S_IN_1, I2S_OUT_1) );
    PanicFalse( StreamConnect(audio_source_a, audio_sink_a) );
    PanicFalse( StreamConnect(audio_source_b, audio_sink_b) );
#endif
}

void led(void)
{
    /* LED indication */
    if(I2S_MASTER)
    {
        LedConfigure(LED_0, LED_ENABLE, 1);
    }
    else
    {
        LedConfigure(LED_1, LED_ENABLE, 1);
    }
}

