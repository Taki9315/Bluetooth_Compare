Program one CNS10001v4 as master using this code, and the other using the Multivoice code.

Connect the two with flying leads between the J5 pins of each board as follows:

Master  Slave
06      06
07      07
08      08
10      10
14      14
15      15
21      22
22      21
23      23
24      24
40      40



Button functions:

11    Toggle input mode          (address 0xF, PIO 6/7)
12    Enable Source (AG) pairing (address 0x4, PIO 6)
13    Set BT mode Source (AG)    (address 0xE, PIO 6)
