#include <stdlib.h>
#include <bdaddr.h>
#include <panic.h>

#include "bluetooth_private.h"
#include "aghfp.h"

/* Uncomment this to enable logging in this file */
/* #define DEBUG_ENABLED */
#include "log.h"


/** AGHFP State Machine */
typedef enum
{
    AGHFP_STATE_DISCONNECTED = 0,
    AGHFP_STATE_CONNECTING_REMOTE,
    AGHFP_STATE_CONNECTED,
    AGHFP_STATE_CONNECTING_AUDIO_REMOTE,
    AGHFP_STATE_CONNECTED_AUDIO,
    AGHFP_STATE_DISCONNECTING_AUDIO,
    AGHFP_STATE_DISCONNECTING
} AGHFP_STATE_T;


/** Structure holding the AGHFP data */
typedef struct aghfpInstance
{
    TaskData aghfpTask;
    AGHFP_STATE_T aghfp_state;
    bdaddr addr;
    AGHFP *aghfp;
    Sink slc_sink;
    Sink audio_sink;
} aghfpInstance;


/** Values used to identify profiles */
typedef enum
{
    PROFILE_NONE   = 0x00,
    PROFILE_AGHFP  = 0x01
} PROFILES_T;


/** Inquiry structures */
typedef struct
{
    int16 path_loss;
    PROFILES_T profiles:4;
    unsigned profiles_complete:1;
} INQUIRY_EIR_DATA_T;


/* EIR tags */
#define EIR_TYPE_LOCAL_NAME_COMPLETE            (0x09)
#define EIR_TYPE_UUID16_PARTIAL                 (0x02)
#define EIR_TYPE_INQUIRY_TX                     (0x0A)
#define EIR_TYPE_UUID16_COMPLETE                (0x03)
#define EIR_TYPE_UUID16_SHORTENED               (0x02)

/* Device UUIDs */
#define BT_UUID_SERVICE_CLASS_A2DP              (0x110D)
#define BT_UUID_SERVICE_CLASS_AUDIO_SOURCE      (0x110A)
#define BT_UUID_SERVICE_CLASS_AUDIO_SINK        (0x110B)
#define BT_UUID_SERVICE_CLASS_AVRCP             (0x110E)
#define BT_UUID_SERVICE_CLASS_AVRCP_CT          (0x110F)
#define BT_UUID_SERVICE_CLASS_AVRCP_TG          (0x110C)
#define BT_UUID_SERVICE_CLASS_HFP_AG            (0x111F)
#define BT_UUID_SERVICE_CLASS_HFP_HF            (0x111E)


/** Maximum Inquiry TX power. */
#define INQUIRY_TX_POWER_MAX                    (127)


/* Stores a aghfp instance to be used for the current connection. */
static aghfpInstance instance;


/**
 * Extracts the profiles from the uuids.
 *
 * @param size_uuids       Size of uuids in octets.
 * @param uuids            An array of uuids.
 *
 * @returns PROFILE_AGHFP if it is supported, else PROFILE_NONE.
 */
static PROFILES_T
inquiry_parse_eir_uuids(const uint8 size_uuids, const uint8 *uuids)
{
    PROFILES_T profiles = PROFILE_NONE;
    uint8 k;
    uint16 uuid;

    for (k = 0; k < size_uuids; k += 2)
    {
        /* Get UUID from data */
        uuid = uuids[k] | (uuids[k+1] << 8);

        if (uuid == BT_UUID_SERVICE_CLASS_HFP_HF)
            profiles |= PROFILE_AGHFP;
    }
    return profiles;
}


/**
 * Extracts the required EIR data found in the inquiry result.
 *
 * @param size_eir_data     The length of the eir_data.
 * @param eir_data          The eir data to extract information from.
 *
 * @returns the extracted eir data.
 */
static INQUIRY_EIR_DATA_T
inquiry_parse_eir_data(const uint8 size_eir_data, const uint8* eir_data)
{
    const uint8* p = eir_data;
    INQUIRY_EIR_DATA_T result;

    /* Default to max possible Inquiry Tx Power */
    result.path_loss = INQUIRY_TX_POWER_MAX;
    result.profiles = PROFILE_NONE;
    result.profiles_complete = FALSE;

    /* Search until no more to read */
    for (p = eir_data; (uint8)(p - eir_data) != size_eir_data; p += (*p)+1)
    {
        /* Check type fields for UUIDs or Inquiry Tx Power */
        if (*(p+1) == EIR_TYPE_INQUIRY_TX)
        {
            /* Initially set path loss to Inquiry Tx Power*/
            result.path_loss = *p+2;
        }
        else if ((*(p+1) == EIR_TYPE_UUID16_COMPLETE) ||
                 (*(p+1) == EIR_TYPE_UUID16_SHORTENED))
        {
            /* Get the profile information */
            result.profiles_complete = (*(p+1) == EIR_TYPE_UUID16_COMPLETE);
            result.profiles = inquiry_parse_eir_uuids(*p , p+2);
        }
    }

    /* Return number of UUIDs found in EIR data */
    return result;
}


/**
 * Connect to a provided Bluetooth address.
 *
 * @param bd_addr       The Bluetooth address to connect with.
 */
static void
bluetooth_aghfp_connect(const bdaddr *bd_addr)
{
    instance.addr = *bd_addr;
    AghfpSlcConnect(instance.aghfp, &(instance.addr));
}


/**
 * Process an inquiry result.
 *
 * @param result        An inquiry result to process.
 */
void
bluetooth_aghfp_process_inquiry_result(CL_DM_INQUIRE_RESULT_T *result)
{
    INQUIRY_EIR_DATA_T parsed_result =
            inquiry_parse_eir_data(result->size_eir_data, result->eir_data);

    /*
     * Ignore all inquiry results if we are in any state other than disconnected
     */
    if (instance.aghfp_state != AGHFP_STATE_DISCONNECTED)
    {
        LOG_DEBUG(("Ignoring inquiry result in state %u\n",
                   instance.aghfp_state));
        return;
    }

    /*
     * If the device found in the inquiry supports HFP then attempt to connect
     * with it.
     */
    if ((parsed_result.profiles & PROFILE_AGHFP) == PROFILE_AGHFP)
    {
        LOG_DEBUG(("Headset found, attempting to connect...\n"));
        LOG_BLUETOOTH_ADDR((result->bd_addr));
        bluetooth_manager_aghfp_pairing();
        bluetooth_aghfp_connect(&(result->bd_addr));
    }
    else
    {
        LOG_DEBUG(("Ignoring inquiry result (parsed_result.profiles 0x%x)\n",
                   parsed_result.profiles));
    }
}


/**
 * Reset the instance before connecting to a new device.
 */
static void
reset_instance(void)
{
    BdaddrSetZero(&instance.addr);
    instance.aghfp_state = AGHFP_STATE_DISCONNECTED;
}


void
bluetooth_aghfp_disconnect(void)
{
    AghfpSlcDisconnect(instance.aghfp);
}


void
bluetooth_aghfp_init(void)
{
    aghfp_profile profile = aghfp_handsfree_17_profile;
    uint16 features = aghfp_voice_recognition | aghfp_enhanced_call_status |
                      aghfp_codec_negotiation | aghfp_esco_s4_supported |
                      aghfp_hf_indicators;

    /* This section is from source_aghfp.c */
    reset_instance();

    AghfpInit(bluetooth_data.task, profile, features);
    LOG_DEBUG(("AGHFP_INIT\n"));
}


void
bluetooth_manager_aghfp_connect(bdaddr *addr)
{
    LOG_DEBUG(("Connnecting to...\n"));
    LOG_BLUETOOTH_ADDRP((addr));

    bluetooth_aghfp_connect(addr);
}


/**
 * Handle the service layer connection disconnecting.
 *
 * @param message       A message from the aghfp library.
 */
static void
aghfp_msg_slc_disconnect_ind(AGHFP_SLC_DISCONNECT_IND_T *message)
{
    /* Set the status to disconnected */
    instance.aghfp_state = AGHFP_STATE_DISCONNECTED;

    /* Reset instance */
    reset_instance();
}


/**
 * Handles AGHFP library message AGHFP_INIT_CFM.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_init_cfm(const AGHFP_INIT_CFM_T *message)
{
    instance.aghfp = message->aghfp;
    bluetooth_manager_aghfp_initialised();
}


/**
 * Handle a aghfp_msg_slc_connect_cfm event.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_slc_connect_cfm(const AGHFP_SLC_CONNECT_CFM_T *message)
{
    /* If the connection was successful t */
    if (message->status == aghfp_success)
    {
        /* Set the state to connected */
        instance.aghfp_state = AGHFP_STATE_CONNECTED;

        /* Store Sink for the connection */
        instance.slc_sink = message->rfcomm_sink;

        /* Now we have a service connection establish an audio connection */
        AghfpAudioConnect(instance.aghfp, sync_all_pkt_types, NULL);
    }
    else
    {
        /* Set the state to disconnected */
        instance.aghfp_state = AGHFP_STATE_DISCONNECTED;
        bluetooth_manager_aghfp_connection_failed();
    }
}


/**
 * Handle a aghfp_msg_slc_connect_ind event.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_slc_connect_ind(const AGHFP_SLC_CONNECT_IND_T *message)
{
    LOG_DEBUG(("Incoming AGHFP SLC from\n"));
    LOG_BLUETOOTH_ADDR(message->bd_addr);
    LOG_DEBUG(("Accepting\n"));

    AghfpSlcConnectResponse(message->aghfp, TRUE);
}


/**
 * Handles the indication that a audio connection is being attempted.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_audio_connect_ind(AGHFP_AUDIO_CONNECT_IND_T *message)
{
    instance.aghfp_state = AGHFP_STATE_CONNECTING_AUDIO_REMOTE;
}


/**
 * Handles the event that a audio connection is confirmed.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_audio_connect_cfm(AGHFP_AUDIO_CONNECT_CFM_T *message)
{
    LOG_DEBUG(("  AGHFP Audio : cl_status:[%d] link_type[%d] audio_sink[0x%x] "
               "rx_bandwidth[0x%lx] tx_bandwidth[0x%lx] using_wbs[%d] "
               "wbs_codec[%d]\n",
               message->cl_status,
               message->link_type,
               (uint16)message->audio_sink,
               message->rx_bandwidth,
               message->tx_bandwidth,
               message->using_wbs,
               message->wbs_codec));

    if (message->status == aghfp_audio_connect_success)
    {
        instance.audio_sink = message->audio_sink;
        instance.aghfp_state = AGHFP_STATE_CONNECTED_AUDIO;
        /* All connected */
        bluetooth_manager_aghfp_connected(&instance.addr);
        bluetooth_manager_sink_changed(message->audio_sink);
    }
    else
    {
        instance.aghfp_state = AGHFP_STATE_CONNECTED;
    }
}


/**
 * Handles the event when the audio connection disconnects.
 *
 * @param message       Message from the AGHFP library.
 */
static void
aghfp_msg_audio_disconnect_ind(AGHFP_AUDIO_DISCONNECT_IND_T *message)
{
    instance.aghfp_state = AGHFP_STATE_DISCONNECTED;
    bluetooth_manager_sink_changed(NULL);
}


void
bluetooth_aghfp_msg_handler(Task task, MessageId id, Message message)
{
    switch (id)
    {
    /* Confirmation that the aghfp lib is initialised */
    case AGHFP_INIT_CFM:
        LOG_DEBUG(("AGHFP_INIT_CFM [%d]:\n",
                   ((AGHFP_INIT_CFM_T *)message)->status));
        aghfp_msg_init_cfm((AGHFP_INIT_CFM_T *)message);
        return;

    /* Confirmation of a connection attempt */
    case AGHFP_SLC_CONNECT_CFM:
        LOG_DEBUG(("AGHFP_SLC_CONNECT_CFM [%d]:\n",
                   ((AGHFP_SLC_CONNECT_CFM_T *)message)->status));
        aghfp_msg_slc_connect_cfm((AGHFP_SLC_CONNECT_CFM_T *)message);
        return;

    /* Confirmation of a connection attempt */
    case AGHFP_SLC_CONNECT_IND:
        aghfp_msg_slc_connect_ind((AGHFP_SLC_CONNECT_IND_T *)message);
        return;

    /* Indication that the connection has been lost */
    case AGHFP_SLC_DISCONNECT_IND:
        LOG_DEBUG(("AGHFP_SLC_DISCONNECT_IND:\n"));
        aghfp_msg_slc_disconnect_ind((AGHFP_SLC_DISCONNECT_IND_T *)message);
        return;

    /* Confirmation of an audio connection request */
    case AGHFP_AUDIO_CONNECT_CFM:
        LOG_DEBUG(("AGHFP_AUDIO_CONNECT_CFM [%d]:\n",
                   ((AGHFP_AUDIO_CONNECT_CFM_T *)message)->status));
        aghfp_msg_audio_connect_cfm((AGHFP_AUDIO_CONNECT_CFM_T *)message);
        return;

    /* Indication that a remote device is trying to connect audio */
    case AGHFP_AUDIO_CONNECT_IND:
        LOG_DEBUG(("AGHFP_AUDIO_CONNECT_IND:\n"));
        aghfp_msg_audio_connect_ind((AGHFP_AUDIO_CONNECT_IND_T *)message);
        return;

    /* Indication that the audio has disconnected */
    case AGHFP_AUDIO_DISCONNECT_IND:
        LOG_DEBUG(("AGHFP_AUDIO_DISCONNECT_IND:\n"));
        aghfp_msg_audio_disconnect_ind((AGHFP_AUDIO_DISCONNECT_IND_T *)message);
        return;

    /* Indication that the audio parameters need to be supplied */
    case AGHFP_APP_AUDIO_PARAMS_REQUIRED_IND:
        /*
         * Implement and call aghfp_send_audio_params() and set the state to
         * AGHFP_STATE_CONNECTING_AUDIO_REMOTE.
         */
        LOG_DEBUG(("AGHFP_APP_AUDIO_PARAMS_REQUIRED_IND:\n"));
        return;

    /* Indication of microphone gain sent from remote device */
    case AGHFP_SYNC_MICROPHONE_GAIN_IND:
        /*
         * The microphone gain can be extracted from
         * (((AGHFP_SYNC_MICROPHONE_GAIN_IND_T *)message)->gain)
         * to be sync.
         */
        LOG_DEBUG(("AGHFP_SYNC_MICROPHONE_GAIN_IND:\n"));
        return;

    /* Indication of speaker volume sent from remote device */
    case AGHFP_SYNC_SPEAKER_VOLUME_IND:
        /*
         * The volume can be extracted from
         * (((AGHFP_SYNC_SPEAKER_VOLUME_IND_T *)message)->volume) and used
         * to sync the speaker volumes.
         */
        LOG_DEBUG(("AGHFP_SYNC_SPEAKER_VOLUME_IND:\n"));
        LOG_DEBUG(("    - %u\n",
                   ((AGHFP_SYNC_SPEAKER_VOLUME_IND_T *)message)->volume));
        return;

    /* Confirmation of setting microphone gain */
    case AGHFP_SET_REMOTE_MICROPHONE_GAIN_CFM:
        LOG_DEBUG(("AGHFP_SET_REMOTE_MICROPHONE_GAIN_CFM:\n"));
        return;

    /* Confirmation of setting speaker volume */
    case AGHFP_SET_REMOTE_SPEAKER_VOLUME_CFM:
        LOG_DEBUG(("AGHFP_SET_REMOTE_SPEAKER_VOLUME_CFM:\n"));
        return;

    /* HF wants voice recognition  */
    case AGHFP_VOICE_RECOGNITION_ENABLE_CFM:
        LOG_DEBUG(("AGHFP_VOICE_RECOGNITION_ENABLE_CFM:\n"));
        return;

    /* Confirmation of sending call indicator */
    case AGHFP_SEND_CALL_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_CALL_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of sending call setup indicator */
    case AGHFP_SEND_CALL_SETUP_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_CALL_SETUP_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of sending ring alert */
    case AGHFP_SEND_RING_ALERT_CFM:
        LOG_DEBUG(("AGHFP_SEND_RING_ALERT_CFM:\n"));
        return;

    /* Confirmation of sending inband ring enable */
    case AGHFP_INBAND_RING_ENABLE_CFM:
        LOG_DEBUG(("AGHFP_INBAND_RING_ENABLE_CFM:\n"));
        return;

    /* Confirmation of sending battery charge */
    case AGHFP_SEND_BATT_CHG_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_BATT_CHG_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of sending service indicator */
    case AGHFP_SEND_SERVICE_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_SERVICE_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of sending HF indicator */
    case AGHFP_SEND_BIND_INDICATOR_STATE_CFM:
        LOG_DEBUG(("AGHFP_SEND_BIND_INDICATOR_STATE_CFM:\n"));
        return;


    /* Confirmation of sending network operator */
    case AGHFP_NETWORK_OPERATOR_CFM:
        LOG_DEBUG(("AGHFP_NETWORK_OPERATOR_CFM:\n"));
        return;

    /* Indication of unrecognised AT command */
    case AGHFP_UNRECOGNISED_AT_CMD_IND:
        LOG_DEBUG(("AGHFP_UNRECOGNISED_AT_CMD_IND:\n"));
        AghfpSendError(((AGHFP_UNRECOGNISED_AT_CMD_IND_T *)message)->aghfp);
        return;

    /* Indication of response hold status request */
    case AGHFP_RESPONSE_HOLD_STATUS_REQUEST_IND:
        LOG_DEBUG(("AGHFP_RESPONSE_HOLD_STATUS_REQUEST_IND:\n"));
        /* Just send OK back since we do not support Response and Hold */
        AghfpSendOk(
                ((AGHFP_RESPONSE_HOLD_STATUS_REQUEST_IND_T *)message)->aghfp);
        return;

    /* Confirmation of sending response hold state request */
    case AGHFP_SEND_RESPONSE_HOLD_STATE_CFM:
        LOG_DEBUG(("AGHFP_SEND_RESPONSE_HOLD_STATE_CFM:\n"));
        return;

    /* Indication of setting response hold status request */
    case AGHFP_SET_RESPONSE_HOLD_STATUS_IND:
        LOG_DEBUG(("AGHFP_SET_RESPONSE_HOLD_STATUS_IND:\n"));
        /* Not in a hold state so don't need AghfpConfirmResponseHoldState so
         * just send OK*/
        AghfpSendOk(((AGHFP_SET_RESPONSE_HOLD_STATUS_IND_T *)message)->aghfp);
        return;

    /* Confirmation of response hold state request */
    case AGHFP_CONFIRM_RESPONSE_HOLD_STATE_CFM:
        LOG_DEBUG(("AGHFP_CONFIRM_RESPONSE_HOLD_STATE_CFM:\n"));
        return;

    /* Indication of indicator activation */
    case AGHFP_INDICATORS_ACTIVATION_IND:
        LOG_DEBUG(("AGHFP_INDICATORS_ACTIVATION_IND:\n"));
        return;

    /* Indication of indicator event reporting */
    case AGHFP_INDICATOR_EVENTS_REPORTING_IND:
        LOG_DEBUG(("AGHFP_INDICATOR_EVENTS_REPORTING_IND: mode[%d] ind[%d]\n",
                   ((AGHFP_INDICATOR_EVENTS_REPORTING_IND_T *)message)->mode,
                   ((AGHFP_INDICATOR_EVENTS_REPORTING_IND_T *)message)->ind));
        return;

    /* HF wants to answer call */
    case AGHFP_ANSWER_IND:
        LOG_DEBUG(("AGHFP_ANSWER_IND:\n"));
        /* Respond with OK */
        AghfpSendOk(((AGHFP_ANSWER_IND_T *)message)->aghfp);
        return;

    /* HF wants to hang up call */
    case AGHFP_CALL_HANG_UP_IND:
        LOG_DEBUG(("AGHFP_CALL_HANG_UP_IND:\n"));
        /* Respond with OK */
        AghfpSendOk(((AGHFP_CALL_HANG_UP_IND_T *)message)->aghfp);
        return;

    /* HF wants to dial number */
    case AGHFP_DIAL_IND:
        LOG_DEBUG(("AGHFP_DIAL_IND:\n"));
        return;

    /* HF wants to dial number from memory  */
    case AGHFP_MEMORY_DIAL_IND:
        LOG_DEBUG(("AGHFP_MEMORY_DIAL_IND:\n"));
        return;

    /* HF wants a last number redial  */
    case AGHFP_LAST_NUMBER_REDIAL_IND:
        LOG_DEBUG(("AGHFP_LAST_NUMBER_REDIAL_IND:\n"));
        return;

    /* Indication of event to get the current calls */
    case AGHFP_CURRENT_CALLS_IND:
        LOG_DEBUG(("AGHFP_CURRENT_CALLS_IND:\n"));
        return;

    case AGHFP_SUBSCRIBER_NUMBER_IND:
        LOG_DEBUG(("AGHFP_SUBSCRIBER_NUMBER_IND:\n"));
        /* Ignore this message for now */
        LOG_DEBUG(("  - ignored\n"));
        AghfpSendSubscriberNumbersComplete(
                ((AGHFP_SUBSCRIBER_NUMBER_IND_T *)message)->aghfp);
        return;

    case AGHFP_SUBSCRIBER_NUMBER_CFM:
        LOG_DEBUG(("AGHFP_SUBSCRIBER_NUMBER_CFM:\n"));
        return;

    case AGHFP_PHONE_NUMBER_REQUEST_IND:
        LOG_DEBUG(("AGHFP_PHONE_NUMBER_REQUEST_IND:\n"));
        /* Ignore this request, send ERROR */
        LOG_DEBUG(("  - ignored, send ERROR\n"));
        AghfpSendError(((AGHFP_PHONE_NUMBER_REQUEST_IND_T *)message)->aghfp);
        return;

    case AGHFP_SET_CALLER_ID_DETAILS_CFM:
        LOG_DEBUG(("AGHFP_SET_CALLER_ID_DETAILS_CFM:\n"));
        return;

    case AGHFP_CALLER_ID_SETUP_IND:
        LOG_DEBUG(("AGHFP_CALLER_ID_SETUP_IND:\n"));
        return;

    case AGHFP_CALL_WAITING_SETUP_IND:
        LOG_DEBUG(("AGHFP_CALL_WAITING_SETUP_IND:\n"));
        return;

    /*HF indicator reported by HF */
    case AGHFP_HF_INDICATORS_REPORT_IND:
        LOG_DEBUG(("AGHFP_HF_INDICATORS_REPORT_IND HF indicator mask = %x\n",
            ((AGHFP_HF_INDICATORS_REPORT_IND_T*)message)->hf_indicators));
        return;

    case AGHFP_HF_INDICATORS_STATUS_REQUEST_IND:
         LOG_DEBUG(("AGHFP_HF_INDICATORS_STATUS_REQUEST_IND:\n"));
         AghfpHfIndicatorsInitStatusResponse(
                 ((AGHFP_HF_INDICATORS_STATUS_REQUEST_IND_T*)message)->aghfp,
                 aghfp_hf_indicator_on << aghfp_battery_level_mask |
                 aghfp_hf_indicator_on << aghfp_enhanced_safety);
         break;

    case AGHFP_SEND_SIGNAL_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_SIGNAL_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of the roaming indicator */
    case AGHFP_SEND_ROAM_INDICATOR_CFM:
        LOG_DEBUG(("AGHFP_SEND_ROAM_INDICATOR_CFM:\n"));
        return;

    /* Confirmation of the caller id */
    case AGHFP_SEND_CALLER_ID_CFM:
        LOG_DEBUG(("AGHFP_SEND_CALLER_ID_CFM %d:\n",
                   ((AGHFP_SEND_CALLER_ID_CFM_T *)message)->status));
        return;

    /* Indication that a call is waiting */
    case AGHFP_SEND_CALL_WAITING_NOTIFICATION_CFM:
        LOG_DEBUG(("AGHFP_SEND_CALL_WAITING_NOTIFICATION_CFM:\n"));
        return;

    /* Indication of remote QTIL supported features */
    case AGHFP_CSR_SUPPORTED_FEATURES_IND:
        LOG_DEBUG(("AGHFP_CSR_SUPPORTED_FEATURES_IND:\n"));
        return;

    /* Indication of QTIL feature negotiation */
    case AGHFP_CSR_FEATURE_NEGOTIATION_IND:
        LOG_DEBUG(("AGHFP_CSR_FEATURE_NEGOTIATION_IND:\n"));
        return;

    /* Indication of QTIL feature negotiation request */
    case AGHFP_CSR_FEATURE_NEGOTIATION_REQ_IND:
        LOG_DEBUG(("AGHFP_CSR_FEATURE_NEGOTIATION_REQ_IND:\n"));
        return;

    default:
        LOG_DEBUG(("Unhandled message (bluetooth_aghfp_msg_handler) 0x%04x\r\n",
                   id));
    }
}

