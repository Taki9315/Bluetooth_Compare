// *****************************************************************************
// Copyright (c) 2007 - 2015 Qualcomm Technologies International, Ltd.
// Part of ADK_CSR867x.WIN. 4.4
//
// *****************************************************************************

// *****************************************************************************
// MODULE:
//    $M.stream_copy_pass
//
// DESCRIPTION:
//    Data is copied from one circular buffer to another.  The amount of data
//    copied is specified by  $stream_copy.NUM_SAMPLES.
//
// INPUTS:
//   r7 -  data object containing pointers to input and output data.  Also
//         contains the number of samples to process.
//
// OUTPUTS:
//   - none
//
// *****************************************************************************
#include "core_library.h"
#include "stream_copy_passthrough.h"
.MODULE $M.stream_copy_pass;
 .codesegment PM;
$stream_copy_pass:

   push rLink;
   // Get Input Buffer
   r0  = M[r7 + $stream_copy_pass.INPUT_PTR_BUFFER_FIELD];
#ifdef BASE_REGISTER_MODE
   call $frmbuffer.get_buffer_with_start_address;
   push r2;
   pop  B0;
#else
   call $frmbuffer.get_buffer;
#endif
   // r0 = buf ptr
   // r1 = circ buf length
   // r2 = buffer base address <base variant only>
   // r3 = frame size
   I0  = r0;
   L0  = r1;

   // Use input frame size
   r10 = r3;
   // Update output frame size from input
   r0 = M[r7 + $stream_copy_pass.OUTPUT_PTR_BUFFER_FIELD];
   call $frmbuffer.set_frame_size;

   // Get output buffer
#ifdef BASE_REGISTER_MODE
   call $frmbuffer.get_buffer_with_start_address;
   push r2;
   pop  B4;
#else
   call $frmbuffer.get_buffer;
#endif
   I4 = r0;
   L4 = r1;
   pop rLink;


// INPUT->OUTPUT
   r0=M[I0,1]; // first input
   do loop_passthru;
      M[I4,1] = r0, r0=M[I0,1]; // copy
   loop_passthru:

// Clear L registers
   L0 = 0;
   L4 = 0;
#ifdef BASE_REGISTER_MODE
   push Null;
   B4 = M[SP-1];
   pop  B0;
#endif
   rts;
.ENDMODULE;
