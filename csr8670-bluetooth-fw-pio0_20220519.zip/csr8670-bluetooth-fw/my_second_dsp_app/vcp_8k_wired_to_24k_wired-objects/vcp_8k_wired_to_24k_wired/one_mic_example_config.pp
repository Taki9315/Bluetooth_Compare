.linefile 1 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
.linefile 1 "<command-line>"
.linefile 1 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
.linefile 9 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
.linefile 1 "vcp_8k_wired_to_24k_wired/one_mic_example.h" 1
.linefile 12 "vcp_8k_wired_to_24k_wired/one_mic_example.h"
.CONST $one_mic_example.REINITIALIZE 1;
.CONST $one_mic_example.VMMSG.SETMODE 4;
.CONST $one_mic_example.VMMSG.READY 5;
.CONST $one_mic_example.MESSAGE_REM_BT_ADDRESS 0x2001;


.CONST $one_mic_example.SYSMODE.PASSTHRU 0;


.CONST $one_mic_example.NUM_SAMPLES_PER_FRAME 60;
.CONST $one_mic_example.JITTER 8;

.CONST $SAMPLE_RATE 8000;
.CONST $BLOCK_SIZE 60;

.CONST $BUFFER_SCALING 4;
.CONST $TONE_BUFFER_SIZE ($BLOCK_SIZE * 2);
.CONST $TWO_MIC_EXAMPLE_BUFFER_SIZE $BLOCK_SIZE;
.linefile 10 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/stream_copy.h" 1
.linefile 12 "vcp_8k_wired_to_24k_wired/stream_copy.h"
.CONST $stream_copy.INPUT_PTR_BUFFER_FIELD 0;
.CONST $stream_copy.OUTPUT_PTR_BUFFER_FIELD 1;
.CONST $stream_copy.OFFSET_INPUT_REF_PTR 2;
.CONST $stream_copy.OFFSET_PTR_REF_STRUC 3;
.CONST $stream_copy.STRUC_SIZE 4;
.linefile 11 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/stream_copy_passthrough.h" 1
.linefile 11 "vcp_8k_wired_to_24k_wired/stream_copy_passthrough.h"
.CONST $stream_copy_pass.INPUT_PTR_BUFFER_FIELD 0;
.CONST $stream_copy_pass.OUTPUT_PTR_BUFFER_FIELD 1;
.CONST $stream_copy_pass.STRUC_SIZE 2;
.linefile 12 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2

.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_buffer.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_buffer.h"
.CONST $framesync_ind.CBUFFER_PTR_FIELD 0;
.CONST $framesync_ind.FRAME_PTR_FIELD 1;
.CONST $framesync_ind.CUR_FRAME_SIZE_FIELD 2;

.CONST $framesync_ind.FRAME_SIZE_FIELD 3;
.CONST $framesync_ind.JITTER_FIELD 4;
.CONST $framesync_ind.DISTRIBUTE_FUNCPTR_FIELD 5;
.CONST $framesync_ind.UPDATE_FUNCPTR_FIELD 6;
.CONST $framesync_ind.COUNTER_FIELD 7;
.CONST $framesync_ind.AMOUNT_DATA_FIELD 8;
.CONST $framesync_ind.THRESHOLD_FIELD 9;
.CONST $framesync_ind.MIN_FIELD 10;
.CONST $framesync_ind.MAX_FIELD 11;
.CONST $framesync_ind.DROP_INSERT_FIELD 12;


.CONST $framesync_ind.SYNC_POINTER_FIELD 7;
.CONST $framesync_ind.SYNC_MULTIPLIER_FIELD 8;
.CONST $framesync_ind.SYNC_AMOUNT_DATA_FIELD 9;



.CONST $framesync_ind.ENTRY_SIZE_FIELD 13;
.linefile 14 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer_defines.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h" 2

   .CONST $cbuffer.SIZE_FIELD 0;
   .CONST $cbuffer.READ_ADDR_FIELD 1;
   .CONST $cbuffer.WRITE_ADDR_FIELD 2;




      .CONST $cbuffer.STRUC_SIZE 3;




   .CONST $frmbuffer.CBUFFER_PTR_FIELD 0;
   .CONST $frmbuffer.FRAME_PTR_FIELD 1;
   .CONST $frmbuffer.FRAME_SIZE_FIELD 2;
   .CONST $frmbuffer.STRUC_SIZE 3;


   .CONST $cbuffer.CALLBACK_PORT_DISCONNECT (0);
   .CONST $cbuffer.CALLBACK_PORT_CONNECT (1);


   .CONST $cbuffer.CONFIGURE_PORT_IS_SCO_METADATA 0x000001;
   .CONST $cbuffer.CONFIGURE_PORT_IS_KAL_METADATA 0x000002;
   .CONST $cbuffer.CONFIGURE_PORT_IS_DMB 0x000004;
   .CONST $cbuffer.DMB_PORT_HEADER_MIN_SIZE 2;
   .CONST $cbuffer.DMB_PORT_HEADER_STD_SIZE 3;
   .CONST $cbuffer.DMB_PORT_HEADER_WORD 0x10C0;
   .CONST $cbuffer.DMB_PORT_HEADER_PORT_MASK 0x00001F;
   .CONST $cbuffer.DMB_PORT_HEADER_MSG_MASK 0x008000;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_MIN_SIZE 2;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_OFFSET_INDEX 0;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_SIZE_INDEX 1;


   .CONST $cbuffer.NUM_PORTS (12);
   .CONST $cbuffer.NUM_MMU_PORTS (11);
   .CONST $cbuffer.WRITE_PORT_OFFSET (0x00000C);
   .CONST $cbuffer.PORT_NUMBER_MASK (0x00000F);
   .CONST $cbuffer.TOTAL_PORT_NUMBER_MASK (0x00001F);
   .CONST $cbuffer.TOTAL_CONTINUOUS_PORTS (8);

   .CONST $cbuffer.MMU_PAGE_SIZE (64);

   .CONST $cbuffer.READ_PORT_MASK (0x800000);
   .CONST $cbuffer.WRITE_PORT_MASK ((0x800000) + (0x00000C));




   .CONST $cbuffer.FORCE_ENDIAN_MASK (0x300000);
   .CONST $cbuffer.FORCE_ENDIAN_SHIFT_AMOUNT (-21);
   .CONST $cbuffer.FORCE_LITTLE_ENDIAN (0x100000);
   .CONST $cbuffer.FORCE_BIG_ENDIAN (0x300000);


   .CONST $cbuffer.FORCE_SIGN_EXTEND_MASK (0x0C0000);
   .CONST $cbuffer.FORCE_SIGN_EXTEND_SHIFT_AMOUNT (-19);
   .CONST $cbuffer.FORCE_SIGN_EXTEND (0x040000);
   .CONST $cbuffer.FORCE_NO_SIGN_EXTEND (0x0C0000);


   .CONST $cbuffer.FORCE_BITWIDTH_MASK (0x038000);
   .CONST $cbuffer.FORCE_BITWIDTH_SHIFT_AMOUNT (-16);
   .CONST $cbuffer.FORCE_8BIT_WORD (0x008000);
   .CONST $cbuffer.FORCE_16BIT_WORD (0x018000);
   .CONST $cbuffer.FORCE_24BIT_WORD (0x028000);
   .CONST $cbuffer.FORCE_32BIT_WORD (0x038000);


   .CONST $cbuffer.FORCE_SATURATE_MASK (0x006000);
   .CONST $cbuffer.FORCE_SATURATE_SHIFT_AMOUNT (-14);
   .CONST $cbuffer.FORCE_NO_SATURATE (0x002000);
   .CONST $cbuffer.FORCE_SATURATE (0x006000);

   .CONST $cbuffer.FORCE_PADDING_MASK (0x001C00);
   .CONST $cbuffer.FORCE_PADDING_SHIFT_AMOUNT (-11);
   .CONST $cbuffer.FORCE_PADDING_NONE (0x000400);
   .CONST $cbuffer.FORCE_PADDING_LS_BYTE (0x000C00);
   .CONST $cbuffer.FORCE_PADDING_MS_BYTE (0x001400);


   .CONST $cbuffer.FORCE_PCM_AUDIO ($cbuffer.FORCE_LITTLE_ENDIAN + $cbuffer.FORCE_SIGN_EXTEND + $cbuffer.FORCE_SATURATE);
   .CONST $cbuffer.FORCE_24B_PCM_AUDIO ($cbuffer.FORCE_LITTLE_ENDIAN + $cbuffer.FORCE_32BIT_WORD + $cbuffer.FORCE_PADDING_MS_BYTE + $cbuffer.FORCE_NO_SATURATE);;

   .CONST $cbuffer.FORCE_16BIT_DATA_STREAM ($cbuffer.FORCE_BIG_ENDIAN + $cbuffer.FORCE_NO_SIGN_EXTEND + $cbuffer.FORCE_NO_SATURATE);
.linefile 15 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_tsksched.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_tsksched.h"
.CONST $FRM_SCHEDULER.COUNT_FIELD 0;
.CONST $FRM_SCHEDULER.MAX_COUNT_FIELD 1;
.CONST $FRM_SCHEDULER.NUM_TASKS_FIELD 2;
.CONST $FRM_SCHEDULER.TOTAL_MIPS_FIELD 3;
.CONST $FRM_SCHEDULER.SEND_MIPS_FIELD 4;
.CONST $FRM_SCHEDULER.TOTALTM_FIELD 5;
.CONST $FRM_SCHEDULER.TOTALSND_FIELD 6;
.CONST $FRM_SCHEDULER.TIMER_FIELD 7;
.CONST $FRM_SCHEDULER.TRIGGER_FIELD 8;
.CONST $FRM_SCHEDULER.TASKS_FIELD 9;
.linefile 16 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/VCP.h" 1
.linefile 17 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm" 2

.MODULE $M.system_config.data;
   .DATASEGMENT DM;
.linefile 30 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
   .VAR snd_pass_thru_obj_a[$stream_copy.STRUC_SIZE] =
    &snd_stream_map_adc,
    &snd_stream_map_i2s_a_out,
    &snd_stream_map_refin,
    &$REF_struc;


   .VAR rcv_pass_thru_obj_a[$stream_copy.STRUC_SIZE] =
    &rcv_stream_map_i2s_a_in,
    &rcv_stream_map_dac_l,0,0;




   .VAR snd_pass_thru_obj_b[$stream_copy_pass.STRUC_SIZE] =
    &snd_stream_map_sco_in,
    &snd_stream_map_i2s_b_out;


   .VAR rcv_pass_thru_obj_b[$stream_copy_pass.STRUC_SIZE] =
    &rcv_stream_map_i2s_b_in,
    &rcv_stream_map_sco_out;





   .VAR snd_pass_thru_obj_c[$stream_copy_pass.STRUC_SIZE] =
    &snd_stream_map_adc_2,
    &snd_stream_map_i2s_c_out;


   .VAR rcv_pass_thru_obj_c[$stream_copy_pass.STRUC_SIZE] =
    &rcv_stream_map_i2s_c_in,
    &rcv_stream_map_dac_r;
.linefile 82 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
   .VAR snd_stream_map_adc[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$adc_in.left.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_input_stream_ind,
      $frame_sync.update_input_streams_ind,
      0 ...;

   .VAR snd_stream_map_adc_2[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$adc_in.right.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_input_stream_ind,
      $frame_sync.update_input_streams_ind,
      0 ...;

      .VAR snd_stream_map_refin[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$dac_out.ref_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_sync_stream_ind,
      $frame_sync.update_sync_streams_ind,
      &snd_stream_map_adc,
      1,
      0 ...;




   .VAR snd_stream_map_i2s_a_out[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$USB_A.out.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      0,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;



   .VAR rcv_stream_map_i2s_a_in[$framesync_ind.ENTRY_SIZE_FIELD] =
       &$USB_A.in.cbuffer_struc,
       0,
       0,
       $one_mic_example.NUM_SAMPLES_PER_FRAME,
       $one_mic_example.JITTER,
       $frame_sync.distribute_input_stream_ind,
       $frame_sync.update_input_streams_ind,
       0 ...;


   .VAR snd_stream_map_i2s_b_out[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$USB_B.out.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      0,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;



   .VAR rcv_stream_map_i2s_b_in[$framesync_ind.ENTRY_SIZE_FIELD] =
       &$USB_B.in.cbuffer_struc,
       0,
       0,
       $one_mic_example.NUM_SAMPLES_PER_FRAME,
       $one_mic_example.JITTER,
       $frame_sync.distribute_input_stream_ind,
       $frame_sync.update_input_streams_ind,
       0 ...;


   .VAR snd_stream_map_i2s_c_out[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$USB_C.out.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      0,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;



   .VAR rcv_stream_map_i2s_c_in[$framesync_ind.ENTRY_SIZE_FIELD] =
       &$USB_C.in.cbuffer_struc,
       0,
       0,
       $one_mic_example.NUM_SAMPLES_PER_FRAME,
       $one_mic_example.JITTER,
       $frame_sync.distribute_input_stream_ind,
       $frame_sync.update_input_streams_ind,
       0 ...;





   .VAR rcv_stream_map_dac_l[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$dac_out.cbuffer_struc_l,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;

   .VAR rcv_stream_map_dac_r[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$dac_out.cbuffer_struc_r,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;



   .VAR snd_stream_map_sco_in[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$sco_data.sco_in.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_input_stream_ind,
      $frame_sync.update_input_streams_ind,
      0 ...;

   .VAR rcv_stream_map_sco_out[$framesync_ind.ENTRY_SIZE_FIELD] =
      &$sco_data.port_out.cbuffer_struc,
      0,
      0,
      $one_mic_example.NUM_SAMPLES_PER_FRAME,
      $one_mic_example.JITTER,
      $frame_sync.distribute_output_stream_ind,
      $frame_sync.update_output_streams_ind,
      0 ...;
.linefile 238 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
.VAR rcv_process_streams[] =
   &rcv_stream_map_i2s_a_in,
   &rcv_stream_map_dac_l,
   &rcv_stream_map_dac_r,
   &rcv_stream_map_i2s_b_in,
   &rcv_stream_map_i2s_c_in,
   &rcv_stream_map_sco_out,
   0;


.VAR snd_process_streams[] =
   &snd_stream_map_adc,
   &snd_stream_map_adc_2,
   &snd_stream_map_i2s_a_out,
   &snd_stream_map_refin,
   &snd_stream_map_sco_in,
   &snd_stream_map_i2s_b_out,
   &snd_stream_map_i2s_c_out,
   0;






   .VAR reinitialize_table[] =

    $frame_sync.sco_initialize, &$sco_data.object, 0,
    0;
.linefile 281 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
   .VAR send_mode_table[] =
    &snd_funcs,

    0;

    .VAR receive_mode_table[] =
    &rcv_funcs,

    0;
.linefile 319 "vcp_8k_wired_to_24k_wired/one_mic_example_config.asm"
  .VAR/DMCIRC $VcpProcBufferMICin[360];
  .VAR/DMCIRC $VcpProcBufferMICout[360];

  .VAR/DMCIRC $VcpProcBufferSPKin[360];
  .VAR/DMCIRC $VcpProcBufferSPKout[360];

  .VAR/DMCIRC $VcpProcBufferREFin[360];

  .VAR $MIC_struc[ 8 ] = &$VcpProcBufferMICin,
                         &$VcpProcBufferMICin ,
                         &$VcpProcBufferMICout,
                         &$VcpProcBufferMICout + LENGTH($VcpProcBufferMICout)/2,
                         LENGTH($VcpProcBufferMICout),
                         0,
                         LENGTH($VcpProcBufferMICin),
                         LENGTH($VcpProcBufferMICout)/2;


  .VAR $SPK_struc[ 8 ] = &$VcpProcBufferSPKin,
                         &$VcpProcBufferSPKin ,
                         &$VcpProcBufferSPKout,
                         &$VcpProcBufferSPKout + LENGTH($VcpProcBufferSPKout)/2,
                         LENGTH($VcpProcBufferSPKout),
                         0,
                         LENGTH($VcpProcBufferSPKin),
                         LENGTH($VcpProcBufferSPKin)/2;

  .VAR $REF_struc[ 8 ] = &$VcpProcBufferREFin,
                         &$VcpProcBufferREFin ,
                         0,
                         0,
                         LENGTH($VcpProcBufferREFin),
                         0,
                         LENGTH($VcpProcBufferREFin),
                         LENGTH($VcpProcBufferREFin)/2;


  .VAR snd_funcs[] =

     $frame_sync.distribute_streams_ind, &snd_process_streams, 0,

     $stream_copy, &snd_pass_thru_obj_a, &$MIC_struc,

     $stream_copy_pass, &snd_pass_thru_obj_b, 0,

     $stream_copy_pass, &snd_pass_thru_obj_c, 0,
     $frame_sync.update_streams_ind, &snd_process_streams, 0,
     0;

  .VAR rcv_funcs[] =

    $frame_sync.distribute_streams_ind, &rcv_process_streams, 0,

    $stream_copy, &rcv_pass_thru_obj_a, &$SPK_struc,

    $stream_copy_pass, &rcv_pass_thru_obj_b, 0,

     $stream_copy_pass, &rcv_pass_thru_obj_c, 0,
    $frame_sync.update_streams_ind, &rcv_process_streams, 0,
    0;
.ENDMODULE;
