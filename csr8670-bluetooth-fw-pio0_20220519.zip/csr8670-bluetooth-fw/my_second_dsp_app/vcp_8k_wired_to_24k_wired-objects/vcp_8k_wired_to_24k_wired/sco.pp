.linefile 1 "vcp_8k_wired_to_24k_wired/sco.asm"
.linefile 1 "<command-line>"
.linefile 1 "vcp_8k_wired_to_24k_wired/sco.asm"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 1







.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/stack.h" 1
.linefile 9 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/timer.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/timer.h"
   .CONST $timer.MAX_TIMER_HANDLERS 50;

   .CONST $timer.LAST_ENTRY -1;

   .CONST $timer.NEXT_ADDR_FIELD 0;
   .CONST $timer.TIME_FIELD 1;
   .CONST $timer.HANDLER_ADDR_FIELD 2;
   .CONST $timer.ID_FIELD 3;
   .CONST $timer.STRUC_SIZE 4;

   .CONST $timer.n_us_delay.SHORT_DELAY 10;
   .CONST $timer.n_us_delay.MEDIUM_DELAY 150;
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message_defines.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/architecture.h" 1
.linefile 19 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/architecture.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon.h" 1
.linefile 14 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon.h"
   .CONST $FLASHWIN1_START 0xFFB000;
   .CONST $FLASHWIN1_SIZE 0x001000;
   .CONST $FLASHWIN2_START 0xFFC000;
   .CONST $FLASHWIN2_SIZE 0x001000;
   .CONST $FLASHWIN3_START 0xFFD000;
   .CONST $FLASHWIN3_SIZE 0x001000;
   .CONST $MCUWIN1_START 0xFFE000;
   .CONST $MCUWIN1_SIZE 0x001000;
   .CONST $MCUWIN2_START 0xFFF000;
   .CONST $MCUWIN2_SIZE 0x000E00;

   .CONST $PMWIN_HI_START 0x020000;
   .CONST $PMWIN_LO_START 0x030000;
   .CONST $PMWIN_24_START 0x040000;
   .CONST $PMWIN_SIZE 0x003000;

   .CONST $FLASHWIN1_LARGE_START 0xD00000;
   .CONST $FLASHWIN1_LARGE_SIZE 0x100000;
   .CONST $FLASHWIN2_LARGE_START 0xE00000;
   .CONST $FLASHWIN2_LARGE_SIZE 0x100000;
   .CONST $FLASHWIN3_LARGE_START 0xF00000;
   .CONST $FLASHWIN3_LARGE_SIZE 0x0D0000;





   .CONST $INT_LOAD_INFO_CLR_REQ_MASK 16384;

   .CONST $INT_SOURCE_TIMER1_POSN 0;
   .CONST $INT_SOURCE_TIMER2_POSN 1;
   .CONST $INT_SOURCE_MCU_POSN 2;
   .CONST $INT_SOURCE_PIO_POSN 3;
   .CONST $INT_SOURCE_MMU_UNMAPPED_POSN 4;
   .CONST $INT_SOURCE_SW0_POSN 5;
   .CONST $INT_SOURCE_SW1_POSN 6;
   .CONST $INT_SOURCE_SW2_POSN 7;
   .CONST $INT_SOURCE_SW3_POSN 8;

   .CONST $INT_SOURCE_TIMER1_MASK 1;
   .CONST $INT_SOURCE_TIMER2_MASK 2;
   .CONST $INT_SOURCE_MCU_MASK 4;
   .CONST $INT_SOURCE_PIO_MASK 8;
   .CONST $INT_SOURCE_MMU_UNMAPPED_MASK 16;
   .CONST $INT_SOURCE_SW0_MASK 32;
   .CONST $INT_SOURCE_SW1_MASK 64;
   .CONST $INT_SOURCE_SW2_MASK 128;
   .CONST $INT_SOURCE_SW3_MASK 256;

   .CONST $INT_SOURCE_TIMER1_EVENT 0;
   .CONST $INT_SOURCE_TIMER2_EVENT 1;
   .CONST $INT_SOURCE_MCU_EVENT 2;
   .CONST $INT_SOURCE_PIO_EVENT 3;
   .CONST $INT_SOURCE_MMU_UNMAPPED_EVENT 4;
   .CONST $INT_SOURCE_SW0_EVENT 5;
   .CONST $INT_SOURCE_SW1_EVENT 6;
   .CONST $INT_SOURCE_SW2_EVENT 7;
   .CONST $INT_SOURCE_SW3_EVENT 8;





   .CONST $CLK_DIV_1 0;
   .CONST $CLK_DIV_2 1;
   .CONST $CLK_DIV_4 3;
   .CONST $CLK_DIV_8 7;
   .CONST $CLK_DIV_16 15;
   .CONST $CLK_DIV_32 31;
   .CONST $CLK_DIV_64 63;
   .CONST $CLK_DIV_128 127;
   .CONST $CLK_DIV_256 255;
   .CONST $CLK_DIV_512 511;
   .CONST $CLK_DIV_1024 1023;
   .CONST $CLK_DIV_2048 2047;
   .CONST $CLK_DIV_4096 4095;
   .CONST $CLK_DIV_8192 8191;
   .CONST $CLK_DIV_16384 16383;


   .CONST $CLK_DIV_MAX $CLK_DIV_64;



   .CONST $N_FLAG 1;
   .CONST $Z_FLAG 2;
   .CONST $C_FLAG 4;
   .CONST $V_FLAG 8;
   .CONST $UD_FLAG 16;
   .CONST $SV_FLAG 32;
   .CONST $BR_FLAG 64;
   .CONST $UM_FLAG 128;

   .CONST $NOT_N_FLAG (65535-$N_FLAG);
   .CONST $NOT_Z_FLAG (65535-$Z_FLAG);
   .CONST $NOT_C_FLAG (65535-$C_FLAG);
   .CONST $NOT_V_FLAG (65535-$V_FLAG);
   .CONST $NOT_UD_FLAG (65535-$UD_FLAG);
   .CONST $NOT_SV_FLAG (65535-$SV_FLAG);
   .CONST $NOT_BR_FLAG (65535-$BR_FLAG);
   .CONST $NOT_UM_FLAG (65535-$UM_FLAG);
.linefile 20 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/architecture.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon_io_defs.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon_io_defs.h"
   .CONST $FLASH_CACHE_SIZE_1K_ENUM 0x000000;
   .CONST $FLASH_CACHE_SIZE_512_ENUM 0x000001;
   .CONST $ADDSUB_SATURATE_ON_OVERFLOW_POSN 0x000000;
   .CONST $ADDSUB_SATURATE_ON_OVERFLOW_MASK 0x000001;
   .CONST $ARITHMETIC_16BIT_MODE_POSN 0x000001;
   .CONST $ARITHMETIC_16BIT_MODE_MASK 0x000002;
   .CONST $DISABLE_UNBIASED_ROUNDING_POSN 0x000002;
   .CONST $DISABLE_UNBIASED_ROUNDING_MASK 0x000004;
   .CONST $DISABLE_FRAC_MULT_ROUNDING_POSN 0x000003;
   .CONST $DISABLE_FRAC_MULT_ROUNDING_MASK 0x000008;
   .CONST $DISABLE_RMAC_STORE_ROUNDING_POSN 0x000004;
   .CONST $DISABLE_RMAC_STORE_ROUNDING_MASK 0x000010;
   .CONST $FLASHWIN_CONFIG_NOSIGNX_POSN 0x000000;
   .CONST $FLASHWIN_CONFIG_NOSIGNX_MASK 0x000001;
   .CONST $FLASHWIN_CONFIG_24BIT_POSN 0x000001;
   .CONST $FLASHWIN_CONFIG_24BIT_MASK 0x000002;
   .CONST $INT_EVENT_TIMER1_POSN 0x000000;
   .CONST $INT_EVENT_TIMER1_MASK 0x000001;
   .CONST $INT_EVENT_TIMER2_POSN 0x000001;
   .CONST $INT_EVENT_TIMER2_MASK 0x000002;
   .CONST $INT_EVENT_XAP_POSN 0x000002;
   .CONST $INT_EVENT_XAP_MASK 0x000004;
   .CONST $INT_EVENT_PIO_POSN 0x000003;
   .CONST $INT_EVENT_PIO_MASK 0x000008;
   .CONST $INT_EVENT_MMU_UNMAPPED_POSN 0x000004;
   .CONST $INT_EVENT_MMU_UNMAPPED_MASK 0x000010;
   .CONST $INT_EVENT_SW0_POSN 0x000005;
   .CONST $INT_EVENT_SW0_MASK 0x000020;
   .CONST $INT_EVENT_SW1_POSN 0x000006;
   .CONST $INT_EVENT_SW1_MASK 0x000040;
   .CONST $INT_EVENT_SW2_POSN 0x000007;
   .CONST $INT_EVENT_SW2_MASK 0x000080;
   .CONST $INT_EVENT_SW3_POSN 0x000008;
   .CONST $INT_EVENT_SW3_MASK 0x000100;
   .CONST $INT_EVENT_GPS_POSN 0x000009;
   .CONST $INT_EVENT_GPS_MASK 0x000200;
   .CONST $BITMODE_POSN 0x000000;
   .CONST $BITMODE_MASK 0x000003;
   .CONST $BITMODE_8BIT_ENUM 0x000000;
   .CONST $BITMODE_16BIT_ENUM 0x000001;
   .CONST $BITMODE_24BIT_ENUM 0x000002;
   .CONST $BYTESWAP_POSN 0x000002;
   .CONST $BYTESWAP_MASK 0x000004;
   .CONST $SATURATE_POSN 0x000003;
   .CONST $SATURATE_MASK 0x000008;
   .CONST $NOSIGNEXT_POSN 0x000003;
   .CONST $NOSIGNEXT_MASK 0x000008;
.linefile 21 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/architecture.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon_io_map.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/gordon_io_map.h"
   .CONST $INT_SW_ERROR_EVENT_TRIGGER 0xFFFE00;
   .CONST $INT_GBL_ENABLE 0xFFFE11;
   .CONST $INT_ENABLE 0xFFFE12;
   .CONST $INT_CLK_SWITCH_EN 0xFFFE13;
   .CONST $INT_SOURCES_EN 0xFFFE14;
   .CONST $INT_PRIORITIES 0xFFFE15;
   .CONST $INT_LOAD_INFO 0xFFFE16;
   .CONST $INT_ACK 0xFFFE17;
   .CONST $INT_SOURCE 0xFFFE18;
   .CONST $INT_SAVE_INFO 0xFFFE19;
   .CONST $INT_ADDR 0xFFFE1A;
   .CONST $DSP2MCU_EVENT_DATA 0xFFFE1B;
   .CONST $PC_STATUS 0xFFFE1C;
   .CONST $MCU2DSP_EVENT_DATA 0xFFFE1D;
   .CONST $DOLOOP_CACHE_EN 0xFFFE1E;
   .CONST $TIMER1_EN 0xFFFE1F;
   .CONST $TIMER2_EN 0xFFFE20;
   .CONST $TIMER1_TRIGGER 0xFFFE21;
   .CONST $TIMER2_TRIGGER 0xFFFE22;
   .CONST $WRITE_PORT0_DATA 0xFFFE23;
   .CONST $WRITE_PORT1_DATA 0xFFFE24;
   .CONST $WRITE_PORT2_DATA 0xFFFE25;
   .CONST $WRITE_PORT3_DATA 0xFFFE26;
   .CONST $WRITE_PORT4_DATA 0xFFFE27;
   .CONST $WRITE_PORT5_DATA 0xFFFE28;
   .CONST $WRITE_PORT6_DATA 0xFFFE29;
   .CONST $WRITE_PORT7_DATA 0xFFFE2A;
   .CONST $READ_PORT0_DATA 0xFFFE2B;
   .CONST $READ_PORT1_DATA 0xFFFE2C;
   .CONST $READ_PORT2_DATA 0xFFFE2D;
   .CONST $READ_PORT3_DATA 0xFFFE2E;
   .CONST $READ_PORT4_DATA 0xFFFE2F;
   .CONST $READ_PORT5_DATA 0xFFFE30;
   .CONST $READ_PORT6_DATA 0xFFFE31;
   .CONST $READ_PORT7_DATA 0xFFFE32;
   .CONST $PORT_BUFFER_SET 0xFFFE33;
   .CONST $WRITE_PORT8_DATA 0xFFFE34;
   .CONST $WRITE_PORT9_DATA 0xFFFE35;
   .CONST $WRITE_PORT10_DATA 0xFFFE36;
   .CONST $READ_PORT8_DATA 0xFFFE38;
   .CONST $READ_PORT9_DATA 0xFFFE39;
   .CONST $READ_PORT10_DATA 0xFFFE3A;
   .CONST $MM_DOLOOP_START 0xFFFE40;
   .CONST $MM_DOLOOP_END 0xFFFE41;
   .CONST $MM_QUOTIENT 0xFFFE42;
   .CONST $MM_REM 0xFFFE43;
   .CONST $MM_RINTLINK 0xFFFE44;
   .CONST $CLOCK_DIVIDE_RATE 0xFFFE4D;
   .CONST $INT_CLOCK_DIVIDE_RATE 0xFFFE4E;
   .CONST $PIO_IN 0xFFFE4F;
   .CONST $PIO2_IN 0xFFFE50;
   .CONST $PIO_OUT 0xFFFE51;
   .CONST $PIO2_OUT 0xFFFE52;
   .CONST $PIO_DIR 0xFFFE53;
   .CONST $PIO2_DIR 0xFFFE54;
   .CONST $PIO_EVENT_EN_MASK 0xFFFE55;
   .CONST $PIO2_EVENT_EN_MASK 0xFFFE56;
   .CONST $INT_SW0_EVENT 0xFFFE57;
   .CONST $INT_SW1_EVENT 0xFFFE58;
   .CONST $INT_SW2_EVENT 0xFFFE59;
   .CONST $INT_SW3_EVENT 0xFFFE5A;
   .CONST $FLASH_WINDOW1_START_ADDR 0xFFFE5B;
   .CONST $FLASH_WINDOW2_START_ADDR 0xFFFE5C;
   .CONST $FLASH_WINDOW3_START_ADDR 0xFFFE5D;
   .CONST $NOSIGNX_MCUWIN1 0xFFFE5F;
   .CONST $NOSIGNX_MCUWIN2 0xFFFE60;
   .CONST $FLASHWIN1_CONFIG 0xFFFE61;
   .CONST $FLASHWIN2_CONFIG 0xFFFE62;
   .CONST $FLASHWIN3_CONFIG 0xFFFE63;
   .CONST $NOSIGNX_PMWIN 0xFFFE64;
   .CONST $PM_WIN_ENABLE 0xFFFE65;
   .CONST $STACK_START_ADDR 0xFFFE66;
   .CONST $STACK_END_ADDR 0xFFFE67;
   .CONST $STACK_POINTER 0xFFFE68;
   .CONST $STACK_OVERFLOW_PC 0xFFFE69;
   .CONST $FRAME_POINTER 0xFFFE6A;
   .CONST $NUM_RUN_CLKS_MS 0xFFFE6B;
   .CONST $NUM_RUN_CLKS_LS 0xFFFE6C;
   .CONST $NUM_INSTRS_MS 0xFFFE6D;
   .CONST $NUM_INSTRS_LS 0xFFFE6E;
   .CONST $NUM_STALLS_MS 0xFFFE6F;
   .CONST $NUM_STALLS_LS 0xFFFE70;
   .CONST $TIMER_TIME 0xFFFE71;
   .CONST $TIMER_TIME_MS 0xFFFE72;
   .CONST $WRITE_PORT0_CONFIG 0xFFFE73;
   .CONST $WRITE_PORT1_CONFIG 0xFFFE74;
   .CONST $WRITE_PORT2_CONFIG 0xFFFE75;
   .CONST $WRITE_PORT3_CONFIG 0xFFFE76;
   .CONST $WRITE_PORT4_CONFIG 0xFFFE77;
   .CONST $WRITE_PORT5_CONFIG 0xFFFE78;
   .CONST $WRITE_PORT6_CONFIG 0xFFFE79;
   .CONST $WRITE_PORT7_CONFIG 0xFFFE7A;
   .CONST $READ_PORT0_CONFIG 0xFFFE7B;
   .CONST $READ_PORT1_CONFIG 0xFFFE7C;
   .CONST $READ_PORT2_CONFIG 0xFFFE7D;
   .CONST $READ_PORT3_CONFIG 0xFFFE7E;
   .CONST $READ_PORT4_CONFIG 0xFFFE7F;
   .CONST $READ_PORT5_CONFIG 0xFFFE80;
   .CONST $READ_PORT6_CONFIG 0xFFFE81;
   .CONST $READ_PORT7_CONFIG 0xFFFE82;
   .CONST $PM_FLASHWIN_START_ADDR 0xFFFE83;
   .CONST $PM_FLASHWIN_SIZE 0xFFFE84;
   .CONST $BITREVERSE_VAL 0xFFFE89;
   .CONST $BITREVERSE_DATA 0xFFFE8A;
   .CONST $BITREVERSE_DATA16 0xFFFE8B;
   .CONST $BITREVERSE_ADDR 0xFFFE8C;
   .CONST $ARITHMETIC_MODE 0xFFFE93;
   .CONST $FORCE_FAST_MMU 0xFFFE94;
   .CONST $DBG_COUNTERS_EN 0xFFFE9F;
   .CONST $PM_FLASHWIN_CACHE_SIZE 0xFFFEE0;
   .CONST $WRITE_PORT8_CONFIG 0xFFFEE1;
   .CONST $WRITE_PORT9_CONFIG 0xFFFEE2;
   .CONST $WRITE_PORT10_CONFIG 0xFFFEE3;
   .CONST $READ_PORT8_CONFIG 0xFFFEE5;
   .CONST $READ_PORT9_CONFIG 0xFFFEE6;
   .CONST $READ_PORT10_CONFIG 0xFFFEE7;

   .CONST $READ_CONFIG_GAP $READ_PORT8_CONFIG - $READ_PORT7_CONFIG;
   .CONST $READ_DATA_GAP $READ_PORT8_DATA - $READ_PORT7_DATA;
   .CONST $WRITE_CONFIG_GAP $WRITE_PORT8_CONFIG - $WRITE_PORT7_CONFIG;
   .CONST $WRITE_DATA_GAP $WRITE_PORT8_DATA - $WRITE_PORT7_DATA;


   .CONST $INT_UNBLOCK $INT_ENABLE;
.linefile 22 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/architecture/architecture.h" 2
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer_defines.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbuffer.h" 2

   .CONST $cbuffer.SIZE_FIELD 0;
   .CONST $cbuffer.READ_ADDR_FIELD 1;
   .CONST $cbuffer.WRITE_ADDR_FIELD 2;




      .CONST $cbuffer.STRUC_SIZE 3;




   .CONST $frmbuffer.CBUFFER_PTR_FIELD 0;
   .CONST $frmbuffer.FRAME_PTR_FIELD 1;
   .CONST $frmbuffer.FRAME_SIZE_FIELD 2;
   .CONST $frmbuffer.STRUC_SIZE 3;


   .CONST $cbuffer.CALLBACK_PORT_DISCONNECT (0);
   .CONST $cbuffer.CALLBACK_PORT_CONNECT (1);


   .CONST $cbuffer.CONFIGURE_PORT_IS_SCO_METADATA 0x000001;
   .CONST $cbuffer.CONFIGURE_PORT_IS_KAL_METADATA 0x000002;
   .CONST $cbuffer.CONFIGURE_PORT_IS_DMB 0x000004;
   .CONST $cbuffer.DMB_PORT_HEADER_MIN_SIZE 2;
   .CONST $cbuffer.DMB_PORT_HEADER_STD_SIZE 3;
   .CONST $cbuffer.DMB_PORT_HEADER_WORD 0x10C0;
   .CONST $cbuffer.DMB_PORT_HEADER_PORT_MASK 0x00001F;
   .CONST $cbuffer.DMB_PORT_HEADER_MSG_MASK 0x008000;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_MIN_SIZE 2;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_OFFSET_INDEX 0;
   .CONST $cbuffer.DMB_CBUFFER_HEADER_SIZE_INDEX 1;


   .CONST $cbuffer.NUM_PORTS (12);
   .CONST $cbuffer.NUM_MMU_PORTS (11);
   .CONST $cbuffer.WRITE_PORT_OFFSET (0x00000C);
   .CONST $cbuffer.PORT_NUMBER_MASK (0x00000F);
   .CONST $cbuffer.TOTAL_PORT_NUMBER_MASK (0x00001F);
   .CONST $cbuffer.TOTAL_CONTINUOUS_PORTS (8);

   .CONST $cbuffer.MMU_PAGE_SIZE (64);

   .CONST $cbuffer.READ_PORT_MASK (0x800000);
   .CONST $cbuffer.WRITE_PORT_MASK ((0x800000) + (0x00000C));




   .CONST $cbuffer.FORCE_ENDIAN_MASK (0x300000);
   .CONST $cbuffer.FORCE_ENDIAN_SHIFT_AMOUNT (-21);
   .CONST $cbuffer.FORCE_LITTLE_ENDIAN (0x100000);
   .CONST $cbuffer.FORCE_BIG_ENDIAN (0x300000);


   .CONST $cbuffer.FORCE_SIGN_EXTEND_MASK (0x0C0000);
   .CONST $cbuffer.FORCE_SIGN_EXTEND_SHIFT_AMOUNT (-19);
   .CONST $cbuffer.FORCE_SIGN_EXTEND (0x040000);
   .CONST $cbuffer.FORCE_NO_SIGN_EXTEND (0x0C0000);


   .CONST $cbuffer.FORCE_BITWIDTH_MASK (0x038000);
   .CONST $cbuffer.FORCE_BITWIDTH_SHIFT_AMOUNT (-16);
   .CONST $cbuffer.FORCE_8BIT_WORD (0x008000);
   .CONST $cbuffer.FORCE_16BIT_WORD (0x018000);
   .CONST $cbuffer.FORCE_24BIT_WORD (0x028000);
   .CONST $cbuffer.FORCE_32BIT_WORD (0x038000);


   .CONST $cbuffer.FORCE_SATURATE_MASK (0x006000);
   .CONST $cbuffer.FORCE_SATURATE_SHIFT_AMOUNT (-14);
   .CONST $cbuffer.FORCE_NO_SATURATE (0x002000);
   .CONST $cbuffer.FORCE_SATURATE (0x006000);

   .CONST $cbuffer.FORCE_PADDING_MASK (0x001C00);
   .CONST $cbuffer.FORCE_PADDING_SHIFT_AMOUNT (-11);
   .CONST $cbuffer.FORCE_PADDING_NONE (0x000400);
   .CONST $cbuffer.FORCE_PADDING_LS_BYTE (0x000C00);
   .CONST $cbuffer.FORCE_PADDING_MS_BYTE (0x001400);


   .CONST $cbuffer.FORCE_PCM_AUDIO ($cbuffer.FORCE_LITTLE_ENDIAN + $cbuffer.FORCE_SIGN_EXTEND + $cbuffer.FORCE_SATURATE);
   .CONST $cbuffer.FORCE_24B_PCM_AUDIO ($cbuffer.FORCE_LITTLE_ENDIAN + $cbuffer.FORCE_32BIT_WORD + $cbuffer.FORCE_PADDING_MS_BYTE + $cbuffer.FORCE_NO_SATURATE);;

   .CONST $cbuffer.FORCE_16BIT_DATA_STREAM ($cbuffer.FORCE_BIG_ENDIAN + $cbuffer.FORCE_NO_SIGN_EXTEND + $cbuffer.FORCE_NO_SATURATE);
.linefile 14 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/message.h" 2






   .CONST $message.MAX_LONG_MESSAGE_TX_PAYLOAD_SIZE 80;
   .CONST $message.MAX_LONG_MESSAGE_RX_PAYLOAD_SIZE 80;



   .CONST $message.MAX_LONG_MESSAGE_TX_SIZE ($message.MAX_LONG_MESSAGE_TX_PAYLOAD_SIZE + 2);
   .CONST $message.MAX_LONG_MESSAGE_RX_SIZE ($message.MAX_LONG_MESSAGE_RX_PAYLOAD_SIZE + 2);


   .CONST $message.QUEUE_SIZE_IN_MSGS (($message.MAX_LONG_MESSAGE_TX_SIZE+3)>>2)+1;


   .CONST $message.QUEUE_SIZE_IN_WORDS ($message.QUEUE_SIZE_IN_MSGS * (1+4));
   .CONST $message.LONG_MESSAGE_BUFFER_SIZE (((($message.MAX_LONG_MESSAGE_RX_SIZE+3)>>2)+1) * 4);



   .CONST $message.MAX_MESSAGE_HANDLERS 50;





   .CONST $message.REATTEMPT_SEND_PERIOD 1000;


   .CONST $message.TO_DSP_SHARED_WIN_SIZE 4;
   .CONST $message.TO_MCU_SHARED_WIN_SIZE 4;
   .CONST $message.ACK_FROM_MCU ($MCUWIN1_START + 0);
   .CONST $message.ACK_FROM_DSP ($MCUWIN1_START + 1);
   .CONST $message.DATA_TO_MCU ($MCUWIN1_START + 2);
   .CONST $message.DATA_TO_DSP ($message.DATA_TO_MCU + $message.TO_MCU_SHARED_WIN_SIZE);
   .CONST $message.LAST_SEQ_FROM_MCU ($message.DATA_TO_DSP + $message.TO_DSP_SHARED_WIN_SIZE + $cbuffer.NUM_MMU_PORTS + $cbuffer.NUM_MMU_PORTS);


   .CONST $message.LAST_ENTRY -1;


   .CONST $message.LONG_MESSAGE_MODE_ID (-2);


   .CONST $message.NEXT_ADDR_FIELD 0;
   .CONST $message.ID_FIELD 1;
   .CONST $message.HANDLER_ADDR_FIELD 2;
   .CONST $message.MASK_FIELD 3;
   .CONST $message.STRUC_SIZE 4;


   .CONST $message.QUEUE_WORDS_PER_MSG (1+4);


   .CONST $message.READY_WITH_META_RX_ENABLE (0x000001);
   .CONST $message.READY_WITH_META_TX_ENABLE (0x000002);
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2

.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/packed_cbuffer.h" 1
.linefile 17 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/packed_cbuffer.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/packed_cbuffer.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/interrupt.h" 1
.linefile 27 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/interrupt.h"
      .CONST $INTERRUPT_STORE_STATE_SIZE 48;
.linefile 14 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pskey.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pskey.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pskey_defines.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pskey.h" 2






   .CONST $pskey.NEXT_ENTRY_FIELD 0;
   .CONST $pskey.KEY_NUM_FIELD 1;
   .CONST $pskey.HANDLER_ADDR_FIELD 2;
   .CONST $pskey.STRUC_SIZE 3;



   .CONST $pskey.MAX_HANDLERS 50;

   .CONST $pskey.LAST_ENTRY -1;
   .CONST $pskey.REATTEMPT_TIME_PERIOD 10000;

   .CONST $pskey.FAILED_READ_LENGTH (-1);;
.linefile 15 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/flash.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/flash.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/flash_defines.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/flash.h" 2






      .CONST $PM_FLASHWIN_SIZE_MAX 0x40000;




   .CONST $flash.get_file_address.MAX_HANDLERS 10;


   .CONST $flash.get_file_address.NEXT_ENTRY_FIELD 0;
   .CONST $flash.get_file_address.FILE_ID_FIELD 1;
   .CONST $flash.get_file_address.HANDLER_ADDR_FIELD 2;
   .CONST $flash.get_file_address.STRUC_SIZE 3;

   .CONST $flash.get_file_address.LAST_ENTRY (0);
   .CONST $flash.get_file_address.REATTEMPT_TIME_PERIOD 10000;

   .CONST $flash.get_file_address.MESSAGE_HANDLER_UNINITIALISED (0);
.linefile 16 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/wall_clock.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/wall_clock.h"
   .CONST $wall_clock.FIRMWARE_WALL_CLOCK_PERIOD_VALUE 625;
   .CONST $wall_clock.FIRMWARE_WALL_CLOCK_PERIOD_SHIFT -1;

   .CONST $wall_clock.UPDATE_TIMER_PERIOD 100000;





   .CONST $wall_clock.MAX_WALL_CLOCKS 7;

   .CONST $wall_clock.LAST_ENTRY -1;

   .CONST $wall_clock.NEXT_ADDR_FIELD 0;
   .CONST $wall_clock.BT_ADDR_TYPE_FIELD 1;
   .CONST $wall_clock.BT_ADDR_WORD0_FIELD 2;
   .CONST $wall_clock.BT_ADDR_WORD1_FIELD 3;
   .CONST $wall_clock.BT_ADDR_WORD2_FIELD 4;
   .CONST $wall_clock.ADJUSTMENT_VALUE_FIELD 5;
   .CONST $wall_clock.CALLBACK_FIELD 6;
   .CONST $wall_clock.TIMER_STRUC_FIELD 7;
   .CONST $wall_clock.STRUC_SIZE 8 + $timer.STRUC_SIZE;

   .CONST $wall_clock.BT_TICKS_IN_7500_US 24;
.linefile 17 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pio.h" 1
.linefile 16 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/pio.h"
   .CONST $pio.NEXT_ADDR_FIELD 0;
   .CONST $pio.PIO_BITMASK_FIELD 1;
   .CONST $pio.PIO2_BITMASK_FIELD 2;
   .CONST $pio.PIO3_BITMASK_FIELD 3;
   .CONST $pio.HANDLER_ADDR_FIELD 4;
   .CONST $pio.STRUC_SIZE 5;



   .CONST $pio.MAX_HANDLERS 20;

   .CONST $pio.LAST_ENTRY -1;
.linefile 18 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/profiler.h" 1
.linefile 40 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/profiler.h"
   .CONST $profiler.MAX_PROFILER_HANDLERS 50;

   .CONST $profiler.LAST_ENTRY -1;





   .CONST $profiler.UNINITIALISED -2;

   .CONST $profiler.NEXT_ADDR_FIELD 0;
   .CONST $profiler.CPU_FRACTION_FIELD 1;
   .CONST $profiler.START_TIME_FIELD 2;
   .CONST $profiler.INT_START_TIME_FIELD 3;
   .CONST $profiler.TOTAL_TIME_FIELD 4;

      .CONST $profiler.RUN_CLKS_MS_START_FIELD 5;
      .CONST $profiler.RUN_CLKS_LS_START_FIELD 6;
      .CONST $profiler.RUN_CLKS_MS_TOTAL_FIELD 7;
      .CONST $profiler.RUN_CLKS_LS_TOTAL_FIELD 8;
      .CONST $profiler.RUN_CLKS_AVERAGE_FIELD 9;
      .CONST $profiler.RUN_CLKS_MS_MAX_FIELD 10;
      .CONST $profiler.RUN_CLKS_LS_MAX_FIELD 11;
      .CONST $profiler.INT_START_CLKS_MS_FIELD 12;
      .CONST $profiler.INT_START_CLKS_LS_FIELD 13;
      .CONST $profiler.INSTRS_MS_START_FIELD 14;
      .CONST $profiler.INSTRS_LS_START_FIELD 15;
      .CONST $profiler.INSTRS_MS_TOTAL_FIELD 16;
      .CONST $profiler.INSTRS_LS_TOTAL_FIELD 17;
      .CONST $profiler.INSTRS_AVERAGE_FIELD 18;
      .CONST $profiler.INSTRS_MS_MAX_FIELD 19;
      .CONST $profiler.INSTRS_LS_MAX_FIELD 20;
      .CONST $profiler.INT_START_INSTRS_MS_FIELD 21;
      .CONST $profiler.INT_START_INSTRS_LS_FIELD 22;
      .CONST $profiler.STALLS_MS_START_FIELD 23;
      .CONST $profiler.STALLS_LS_START_FIELD 24;
      .CONST $profiler.STALLS_MS_TOTAL_FIELD 25;
      .CONST $profiler.STALLS_LS_TOTAL_FIELD 26;
      .CONST $profiler.STALLS_AVERAGE_FIELD 27;
      .CONST $profiler.STALLS_MS_MAX_FIELD 28;
      .CONST $profiler.STALLS_LS_MAX_FIELD 29;
      .CONST $profiler.INT_START_STALLS_MS_FIELD 30;
      .CONST $profiler.INT_START_STALLS_LS_FIELD 31;
      .CONST $profiler.TEMP_COUNT_FIELD 32;
      .CONST $profiler.COUNT_FIELD 33;
      .CONST $profiler.STRUC_SIZE 34;
.linefile 19 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/fwrandom.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/fwrandom.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/fwrandom_defines.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/fwrandom.h" 2






   .CONST $fwrandom.NEXT_ENTRY_FIELD 0;
   .CONST $fwrandom.NUM_REQ_FIELD 1;
   .CONST $fwrandom.NUM_RESP_FIELD 2;
   .CONST $fwrandom.RESP_BUF_FIELD 3;
   .CONST $fwrandom.HANDLER_ADDR_FIELD 4;
   .CONST $fwrandom.STRUC_SIZE 5;



   .CONST $fwrandom.MAX_HANDLERS 50;

   .CONST $fwrandom.LAST_ENTRY -1;
   .CONST $fwrandom.REATTEMPT_TIME_PERIOD 10000;
   .CONST $fwrandom.MAX_RAND_BITS 512;

   .CONST $fwrandom.FAILED_READ_LENGTH (-1);

   .CONST $fwrandom.READ_FAILED (0);
   .CONST $fwrandom.READ_SUCCEEDED (1);
.linefile 20 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 18 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/packed_cbuffer.h" 2


   .CONST $packed_cbuffer.READ_BYTEPOS_FIELD 0 + $cbuffer.STRUC_SIZE;
   .CONST $packed_cbuffer.WRITE_BYTEPOS_FIELD 1 + $cbuffer.STRUC_SIZE;
   .CONST $packed_cbuffer.STRUC_SIZE 1 + $packed_cbuffer.WRITE_BYTEPOS_FIELD;
   .CONST $packed_cbuffer.INIT_BYTEPOS 2;
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 2
.linefile 2 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h"
   .CONST $cbops_multirate.BUFFER_TABLE_FIELD 0;
   .CONST $cbops_multirate.MAIN_FIRST_OPERATOR_FIELD 1;
   .CONST $cbops_multirate.MTU_FIRST_OPERATOR_FIELD 2;
   .CONST $cbops_multirate.NUM_INPUTS_FIELD 3;


   .CONST $cbops_multirate.BufferTable.BUFFER_FIELD 0;
   .CONST $cbops_multirate.BufferTable.POINTER_FIELD 1;
   .CONST $cbops_multirate.BufferTable.TRANSFER_FIELD 2;
   .CONST $cbops_multirate.BufferTable.ENTRY_SIZE 3;


   .CONST $cbops_multirate.MTU_NEXT_OPERATOR_FIELD 0;
   .CONST $cbops_multirate.MAIN_NEXT_OPERATOR_FIELD 1;
   .CONST $cbops_multirate.FUNCTION_VECTOR_FIELD 2;
   .CONST $cbops_multirate.PARAMETER_AREA_START_FIELD 3;
   .CONST $cbops_multirate.STRUC_SIZE 4;

   .CONST $cbops.NO_MORE_OPERATORS -1;


.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_vector_table.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_vector_table.h"
   .CONST $cbops.function_vector.RESET_FIELD 0;
   .CONST $cbops.function_vector.AMOUNT_TO_USE_FIELD 1;
   .CONST $cbops.function_vector.MAIN_FIELD 2;
   .CONST $cbops.function_vector.STRUC_SIZE 3;

   .CONST $cbops.function_vector.NO_FUNCTION 0;
.linefile 35 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2


.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_copy_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_copy_op.h"
   .CONST $cbops.copy_op.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.copy_op.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.copy_op.STRUC_SIZE 2;
.linefile 38 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_one_to_two_chan_copy.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_one_to_two_chan_copy.h"
   .CONST $cbops.one_to_two_chan_copy.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.one_to_two_chan_copy.OUTPUT_A_START_INDEX_FIELD 1;
   .CONST $cbops.one_to_two_chan_copy.OUTPUT_B_START_INDEX_FIELD 2;
   .CONST $cbops.one_to_two_chan_copy.STRUC_SIZE 3;
.linefile 39 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_shift.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_shift.h"
   .CONST $cbops.shift.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.shift.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.shift.SHIFT_AMOUNT_FIELD 2;
   .CONST $cbops.shift.STRUC_SIZE 3;
.linefile 40 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_dither_and_shift.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_dither_and_shift.h"
   .CONST $cbops.dither_and_shift.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.dither_and_shift.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.dither_and_shift.SHIFT_AMOUNT_FIELD 2;
   .CONST $cbops.dither_and_shift.DITHER_TYPE_FIELD 3;
   .CONST $cbops.dither_and_shift.DITHER_FILTER_HIST_FIELD 4;
   .CONST $cbops.dither_and_shift.ENABLE_COMPRESSOR_FIELD 5;
   .CONST $cbops.dither_and_shift.STRUC_SIZE 6;


   .CONST $cbops.dither_and_shift.DITHER_TYPE_NONE 0;
   .CONST $cbops.dither_and_shift.DITHER_TYPE_TRIANGULAR 1;
   .CONST $cbops.dither_and_shift.DITHER_TYPE_SHAPED 2;




      .CONST $cbops.dither_and_shift.FILTER_COEFF_SIZE 5;
.linefile 41 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_rate_adjustment_and_shift.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_rate_adjustment_and_shift.h"
   .CONST $cbops.rate_adjustment_and_shift.INPUT1_START_INDEX_FIELD 0;
   .CONST $cbops.rate_adjustment_and_shift.OUTPUT1_START_INDEX_FIELD 1;
   .CONST $cbops.rate_adjustment_and_shift.SHIFT_AMOUNT_FIELD 2;
   .CONST $cbops.rate_adjustment_and_shift.MASTER_OP_FIELD 3;
   .CONST $cbops.rate_adjustment_and_shift.FILTER_COEFFS_FIELD 4;
   .CONST $cbops.rate_adjustment_and_shift.HIST1_BUF_FIELD 5;
   .CONST $cbops.rate_adjustment_and_shift.HIST1_BUF_START_FIELD 6;
   .CONST $cbops.rate_adjustment_and_shift.SRA_TARGET_RATE_ADDR_FIELD 7;
   .CONST $cbops.rate_adjustment_and_shift.ENABLE_COMPRESSOR_FIELD 8;
   .CONST $cbops.rate_adjustment_and_shift.SRA_CURRENT_RATE_FIELD 9;
   .CONST $cbops.rate_adjustment_and_shift.RF 10;
   .CONST $cbops.rate_adjustment_and_shift.PREV_SHORT_SAMPLES_FIELD 11;
   .CONST $cbops.rate_adjustment_and_shift.WORKING_STATE_FIELD 12;
   .CONST $cbops.rate_adjustment_and_shift.TEMP_VAR_FIELD 13;

   .CONST $cbops.rate_adjustment_and_shift.STRUC_SIZE 14;


   .CONST $cbops.rate_adjustment_and_shift.SRA_UPRATE 21;
.linefile 41 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_rate_adjustment_and_shift.h"
      .CONST $cbops.rate_adjustment_and_shift.SRA_COEFFS_SIZE 12;






  .CONST $sra.MOVING_STEP (0.0015*(1.0/1000.0)/10.0);
.linefile 42 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_switch_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_switch_op.h"
   .CONST $cbops.switch_op.PTR_STATE_FIELD 0;
   .CONST $cbops.switch_op.MTU_NEXT_TRUE_FIELD 1;
   .CONST $cbops.switch_op.MTU_NEXT_FALSE_FIELD 2;
   .CONST $cbops.switch_op.MAIN_NEXT_TRUE_FIELD 3;
   .CONST $cbops.switch_op.MAIN_NEXT_FALSE_FIELD 4;
   .CONST $cbops.switch_op.STRUC_SIZE 5;

   .CONST $cbops.mux_1to2_op.PTR_STATE_FIELD 0;
   .CONST $cbops.mux_1to2_op.NEXT_TRUE_FIELD 1;
   .CONST $cbops.mux_1to2_op.NEXT_FALSE_FIELD 2;
   .CONST $cbops.mux_1to2_op.STRUC_SIZE 3;


   .CONST $cbops.demux_2to1_op.PTR_STATE_FIELD 0;
   .CONST $cbops.demux_2to1_op.PREV_TRUE_FIELD 1;
   .CONST $cbops.demux_2to1_op.PREV_FALSE_FIELD 2;
   .CONST $cbops.demux_2to1_op.STRUC_SIZE 3;
.linefile 43 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_compress_copy_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_compress_copy_op.h"
   .CONST $cbops.compress_copy_op.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.compress_copy_op.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.compress_copy_op.SHIFT_AMOUNT 2;
   .CONST $cbops.compress_copy_op.STRUC_SIZE 3;

   .CONST $COMPRESS_RANGE 0.1087;
.linefile 44 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_dc_remove.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_dc_remove.h"
   .CONST $cbops.dc_remove.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.dc_remove.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.dc_remove.DC_ESTIMATE_FIELD 2;
   .CONST $cbops.dc_remove.STRUC_SIZE 3;



   .CONST $cbops.dc_remove.FILTER_COEF 0.0005;
.linefile 45 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_av_copy_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_av_copy_op.h"
.CONST $cbops.av_copy_op.INPUT_LEFT_INDEX_FIELD 0;
.CONST $cbops.av_copy_op.INPUT_RIGHT_INDEX_FIELD 1;
.CONST $cbops.av_copy_op.OUTPUT_LEFT_INDEX_FIELD 2;
.CONST $cbops.av_copy_op.OUTPUT_RIGHT_INDEX_FIELD 3;
.CONST $cbops.av_copy_op.AVERAGE_DATA_FIELD 4;
.CONST $cbops.av_copy_op.PREV_PORT_SPACE_FIELD 5;
.CONST $cbops.av_copy_op.PREV_BUFFER_PTR_FIELD 6;
.CONST $cbops.av_copy_op.READ_ADDR_COUNTER_FIELD 7;
.CONST $cbops.av_copy_op.AMOUNT_DATA_BUF_LEFT 8;
.CONST $cbops.av_copy_op.AMOUNT_DATA_BUF_RIGHT 9;
.CONST $cbops.av_copy_op.STRUC_SIZE 10;


.CONST $CBOPS_AV_COPY_INITIAL_AVERAGE 5800;
.linefile 46 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_stereo_sync_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_stereo_sync_op.h"
   .CONST $cbops.stereo_sync_op.START1_INDEX_FIELD 0;
   .CONST $cbops.stereo_sync_op.START2_INDEX_FIELD 1;
   .CONST $cbops.stereo_sync_op.STRUC_SIZE 2;
.linefile 47 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2

.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_sidetone_filter_operator.h" 1
.linefile 9 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_sidetone_filter_operator.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/peq.h" 1
.linefile 17 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/peq.h"
    .CONST $audio_proc.peq.parameter.NUM_STAGES_FIELD 0;
    .CONST $audio_proc.peq.parameter.GAIN_EXPONENT_FIELD 1;
    .CONST $audio_proc.peq.parameter.GAIN_MANTISA__FIELD 2;
    .CONST $audio_proc.peq.parameter.STAGES_SCALES 3;
.linefile 33 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/peq.h"
   .CONST $audio_proc.peq.INPUT_ADDR_FIELD 0;


   .CONST $audio_proc.peq.OUTPUT_ADDR_FIELD 1;


   .CONST $audio_proc.peq.MAX_STAGES_FIELD 2;

   .CONST $audio_proc.peq.PARAM_PTR_FIELD 3;



   .CONST $audio_proc.peq.DELAYLINE_START_ADDR_FIELD 4;
   .CONST $audio_proc.peq.DELAYLINE_ADDR_FIELD 5;


   .CONST $audio_proc.peq.COEFS_ADDR_FIELD 6;




   .CONST $audio_proc.peq.NUM_STAGES_FIELD 7;



   .CONST $audio_proc.peq.DELAYLINE_SIZE_FIELD 8;



   .CONST $audio_proc.peq.COEFS_SIZE_FIELD 9;


   .CONST $audio_proc.peq.STRUC_SIZE 10;
.linefile 76 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/peq.h"
    .CONST $audio_proc.peq.PEQ_HEADROOM_SHIFTS 2;
    .CONST $audio_proc.peq.HQ_PEQ_HEADROOM_SHIFTS 1;
    .CONST $audio_proc.peq.DH_PEQ_HEADROOM_SHIFTS 2;


    .CONST $audio_proc.peq.const.NUM_STAGES_MASK 0xFF;
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_sidetone_filter_operator.h" 2




.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_ST_CLIP_POINT 0;

.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_ST_ADJUST_LIMIT 1;




.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_STF_SWITCH 2;

.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_STF_NOISE_LOW_THRES 3;

.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_STF_NOISE_HIGH_THRES 4;

.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_STF_GAIN_EXP 5;
.CONST $cbops.sidetone_filter_op.Parameter.OFFSET_STF_GAIN_MANTISSA 6;

.CONST $cbops.sidetone_filter_op.Parameter.BLOCKSIZE 7;



.CONST $cbops.sidetone_filter_op.INPUT_START_INDEX_FIELD 0;
.CONST $cbops.sidetone_filter_op.OUTPUT_START_INDEX_FIELD 1;
.CONST $cbops.sidetone_filter_op.ENABLE_MASK_FIELD 2;
.CONST $cbops.sidetone_filter_op.PARAM_PTR_FIELD 3;

.CONST $cbops.sidetone_filter_op.APPLY_FILTER 4;
.CONST $cbops.sidetone_filter_op.APPLY_GAIN_FIELD 5;


.CONST $cbops.sidetone_filter_op.NOISE_LEVEL_PTR_FIELD 6;

.CONST $cbops.sidetone_filter_op.OFFSET_ST_CONFIG_FIELD 7;

.CONST $cbops.sidetone_filter_op.OFFSET_PTR_INV_DAC_GAIN 8;

.CONST $cbops.sidetone_filter_op.OFFSET_CURRENT_SIDETONE_GAIN 9;

.CONST $cbops.sidetone_filter_op.OFFSET_PEAK_ST 10;

.CONST $cbops.sidetone_filter_op.PEQ_START_FIELD 11;
.linefile 49 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_sidetone_mix_operator.h" 1
.linefile 9 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_sidetone_mix_operator.h"
   .CONST $cbops.sidetone_mix_op.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.sidetone_mix_op.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.sidetone_mix_op.SIDETONE_START_INDEX_FIELD 2;
   .CONST $cbops.sidetone_mix_op.SIDETONE_MAX_SAMPLES_FIELD 3;
   .CONST $cbops.sidetone_mix_op.ATTENUATION_PTR_FIELD 4;
   .CONST $cbops.sidetone_mix_op.STRUC_SIZE 5;
.linefile 50 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_hw_warp_operator.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_hw_warp_operator.h"
.CONST $cbops.hw_warp_op.PORT_OFFSET 0;
.CONST $cbops.hw_warp_op.MONITOR_INDEX_OFFSET 1;
.CONST $cbops.hw_warp_op.WHICH_PORTS_OFFSET 2;
.CONST $cbops.hw_warp_op.TARGET_RATE_OFFSET 3;
.CONST $cbops.hw_warp_op.PERIODS_PER_SECOND_OFFSET 4;
.CONST $cbops.hw_warp_op.COLLECT_SECONDS_OFFSET 5;
.CONST $cbops.hw_warp_op.ENABLE_DITHER_OFFSET 6;

.CONST $cbops.hw_warp_op.ACCUMULATOR_OFFSET 7;
.CONST $cbops.hw_warp_op.PERIOD_COUNTER_OFFSET 8;
.CONST $cbops.hw_warp_op.LAST_WARP_OFFSET 9;

.CONST $cbops.hw_warp_op.STRUC_SIZE 10;
.linefile 40 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_hw_warp_operator.h"
.CONST $cbops.hw_warp_op.PORT_MASK_ADC_BITMASK 0xFF;
.CONST $cbops.hw_warp_op.PORT_MASK_ADC_BITMASK_INST012 0x3F;
.CONST $cbops.hw_warp_op.PORT_MASK_DAC_BITMASK $cbops.hw_warp_op.PORT_MASK_ADC_BITMASK;
.CONST $cbops.hw_warp_op.PORT_MASK_DAC_BITMASK_INST0 0x03;
.CONST $cbops.hw_warp_op.PORT_MASK_DAC_START_POS 8;
.linefile 51 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_aux_mix_operator.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_aux_mix_operator.h"
   .CONST $cbops.aux_audio_mix_op.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.aux_audio_mix_op.OUTPUT_START_INDEX_FIELD 1;

   .CONST $cbops.aux_audio_mix_op.TONE_PORT_FIELD 2;
   .CONST $cbops.aux_audio_mix_op.TONE_BUFFER_FIELD 3;

   .CONST $cbops.aux_audio_mix_op.TIMER_FIELD 4;
   .CONST $cbops.aux_audio_mix_op.TIMER_HOLD_FIELD 5;
   .CONST $cbops.aux_audio_mix_op.AUX_GAIN_FIELD 6;
   .CONST $cbops.aux_audio_mix_op.PRIM_GAIN_FIELD 7;
   .CONST $cbops.aux_audio_mix_op.OFFSET_INV_DAC_GAIN 8;

   .CONST $cbops.aux_audio_mix_op.CLIP_POINT_FIELD 9;
   .CONST $cbops.aux_audio_mix_op.BOOST_CLIP_POINT_FIELD 10;
   .CONST $cbops.aux_audio_mix_op.BOOST_FIELD 11;
   .CONST $cbops.aux_audio_mix_op.PEAK_AUXVAL_FIELD 12;
   .CONST $cbops.aux_audio_mix_op.AUX_GAIN_ADJUST_FIELD 13;
   .CONST $cbops.aux_audio_mix_op.INTERNAL_BUF_PTR_FIELD 14;

   .CONST $cbops.aux_audio_mix_op.STRUC_SIZE 15;
.linefile 52 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_port_wrap_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_port_wrap_op.h"
.CONST $cbops.port_wrap_op.OUTPUT1_INDEX_FIELD 0;
.CONST $cbops.port_wrap_op.OUTPUT2_INDEX_FIELD 1;
.CONST $cbops.port_wrap_op.BUFFER_ADJUST_FIELD 2;
.CONST $cbops.port_wrap_op.MAX_ADVANCE_FIELD 3;
.CONST $cbops.port_wrap_op.SYNC_INDEX_FIELD 4;

.CONST $cbops.port_wrap_op.WRAP_COUNT_FIELD 5;
.CONST $cbops.port_wrap_op.STRUC_SIZE 6;
.linefile 53 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_insert_op.h" 1
.linefile 12 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_insert_op.h"
.CONST $cbops.insert_op.BUFFER_INDEX_FIELD 0;
.CONST $cbops.insert_op.MAX_ADVANCE_FIELD 1;

.CONST $cbops.insert_op.DATA_AMOUNT_FIELD 2;
.CONST $cbops.insert_op.STRUC_SIZE 3;



.CONST $cbops.insert_copy_op.INPUT_BUFFER_INDEX_FIELD 0;
.CONST $cbops.insert_copy_op.OUTPUT_BUFFER_INDEX_FIELD 1;
.CONST $cbops.insert_copy_op.MAX_ADVANCE_FIELD 2;
.CONST $cbops.insert_copy_op.STRUC_SIZE 3;
.linefile 54 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_rate_moniter_op.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_rate_moniter_op.h"
.CONST $cbops.rate_monitor_op.MONITOR_INDEX_FIELD 0;
.CONST $cbops.rate_monitor_op.PERIODS_PER_SECOND_FIELD 1;
.CONST $cbops.rate_monitor_op.SECONDS_TRACKED_FIELD 2;
.CONST $cbops.rate_monitor_op.TARGET_RATE_FIELD 3;
.CONST $cbops.rate_monitor_op.ALPHA_LIMIT_FIELD 4;
.CONST $cbops.rate_monitor_op.AVERAGE_IO_RATIO_FIELD 5;
.CONST $cbops.rate_monitor_op.WARP_MSG_LIMIT_FIELD 6;
.CONST $cbops.rate_monitor_op.IDLE_PERIODS_AFTER_STALL_FIELD 7;


.CONST $cbops.rate_monitor_op.ACCUMULATOR_FIELD 8;
.CONST $cbops.rate_monitor_op.COUNTER_FIELD 9;
.CONST $cbops.rate_monitor_op.STALL_FIELD 10;
.CONST $cbops.rate_monitor_op.LAST_ACCUMULATION_FIELD 11;
.CONST $cbops.rate_monitor_op.CURRENT_ALPHA_INDEX_FIELD 12;
.CONST $cbops.rate_monitor_op.INVERSE_WARP_VALUE_FIELD 13;
.CONST $cbops.rate_monitor_op.WARP_VALUE_FIELD 14;
.CONST $cbops.rate_monitor_op.WARP_MSG_COUNTER_FIELD 15;

.CONST $cbops.rate_monitor_op.DEBUG_STALL_COUNT_FIELD 16;
.CONST $cbops.rate_monitor_op.DEBUG_LAST_PERIOD_COUNT_FIELD 17;
.CONST $cbops.rate_monitor_op.DEBUG_TIMER_PERIOD_FIELD 18;
.CONST $cbops.rate_monitor_op.DEBUG_ALG_RESTART_COUNT_FIELD 19;
.CONST $cbops.rate_monitor_op.DEBUG_INSTANTANEOUS_IO_RATIO_FIELD 20;

.CONST $cbops.rate_monitor_op.STRUC_SIZE 21;


.CONST $cbops.rate_monitor_op.NO_DATA_PERIODS_FOR_STALL 3;
.CONST $cbops.rate_monitor_op.ALG_RESTART_THRESHOLD 0.0005;
.linefile 55 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_usb_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_usb_op.h"
.CONST $cbops.usb_in_op.INPUT_INDEX_FIELD 0;
.CONST $cbops.usb_in_op.OUTPUT1_INDEX_FIELD 1;
.CONST $cbops.usb_in_op.OUTPUT2_INDEX_FIELD 2;
.CONST $cbops.usb_in_op.PKT_LENGTH_FIELD 3;
.CONST $cbops.usb_in_op.LAST_HEADER_FIELD 4;
.CONST $cbops.usb_in_op.STRUC_SIZE 5;

.CONST $cbops.usb_out_op.INPUT1_INDEX_FIELD 0;
.CONST $cbops.usb_out_op.INPUT2_INDEX_FIELD 1;
.CONST $cbops.usb_out_op.OUTPUT_INDEX_FIELD 2;
.CONST $cbops.usb_out_op.PACKET_PERIOD_FIELD 3;
.CONST $cbops.usb_out_op.STALL_COUNT_FIELD 4;
.CONST $cbops.usb_out_op.LAST_LIMIT_FIELD 5;
.CONST $cbops.usb_out_op.PACKET_BUFFER_DATA_FIELD 6;
.CONST $cbops.usb_out_op.PACKET_BUFFER_START_FIELD 7;
.CONST $cbops.usb_out_op.STRUC_SIZE 7;


.CONST $CBOPS_USB_STALL_CNT_THRESH 7;
.linefile 56 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_conditional_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_conditional_op.h"
   .CONST $cbops.conditional_op.MASK_FIELD 0;
   .CONST $cbops.conditional_op.COND_PTR_FIELD 1;
   .CONST $cbops.conditional_op.OP_PTR_FIELD 2;
   .CONST $cbops.conditional_op.STRUC_SIZE 3;
.linefile 57 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_s_to_m_op.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_s_to_m_op.h"
   .CONST $cbops.s_to_m_op.INPUT_LEFT_INDEX_FIELD 0;
   .CONST $cbops.s_to_m_op.INPUT_RIGHT_INDEX_FIELD 1;
   .CONST $cbops.s_to_m_op.OUTPUT_MONO_INDEX_FIELD 2;
   .CONST $cbops.s_to_m_op.STRUC_SIZE 3;
.linefile 58 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_soft_mute_op.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_soft_mute_op.h"
    .const $cbops.soft_mute_op.INPUT_START_INDEX_FIELD 0;
    .const $cbops.soft_mute_op.OUTPUT_START_INDEX_FIELD 1;
    .const $cbops.soft_mute_op.MUTE_DIRECTION 2;
    .const $cbops.soft_mute_op.MUTE_INDEX 3;
 .const $cbops.soft_mute_op.STRUC_SIZE 4;
.linefile 59 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_cmpd_op.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_cmpd_op.h"
.CONST $cbops.cmpd_op.Parameter.OFFSET_EXPAND_THRESHOLD 0;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LINEAR_THRESHOLD 1;
.CONST $cbops.cmpd_op.Parameter.OFFSET_COMPRESS_THRESHOLD 2;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LIMIT_THRESHOLD 3;
.CONST $cbops.cmpd_op.Parameter.OFFSET_INV_EXPAND_RATIO 4;
.CONST $cbops.cmpd_op.Parameter.OFFSET_INV_LINEAR_RATIO 5;
.CONST $cbops.cmpd_op.Parameter.OFFSET_INV_COMPRESS_RATIO 6;
.CONST $cbops.cmpd_op.Parameter.OFFSET_INV_LIMIT_RATIO 7;
.CONST $cbops.cmpd_op.Parameter.OFFSET_EXPAND_ATTACK_TC 8;
.CONST $cbops.cmpd_op.Parameter.OFFSET_EXPAND_DECAY_TC 9;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LINEAR_ATTACK_TC 10;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LINEAR_DECAY_TC 11;
.CONST $cbops.cmpd_op.Parameter.OFFSET_COMPRESS_ATTACK_TC 12;
.CONST $cbops.cmpd_op.Parameter.OFFSET_COMPRESS_DECAY_TC 13;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LIMIT_ATTACK_TC 14;
.CONST $cbops.cmpd_op.Parameter.OFFSET_LIMIT_DECAY_TC 15;
.CONST $cbops.cmpd_op.Parameter.OFFSET_MAKEUP_GAIN 16;
.CONST $cbops.cmpd_op.Parameter.STRUC_SIZE 17;


.CONST $cbops.cmpd_op.INPUT_1_START_INDEX_FIELD 0;
.CONST $cbops.cmpd_op.INPUT_2_START_INDEX_FIELD 1;
.CONST $cbops.cmpd_op.OUTPUT_1_START_INDEX_FIELD 2;
.CONST $cbops.cmpd_op.OUTPUT_2_START_INDEX_FIELD 3;
.CONST $cbops.cmpd_op.OFFSET_PARAM_PTR 4;
.CONST $cbops.cmpd_op.OFFSET_SAMPLES_FOR_PROCESS 5;
.CONST $cbops.cmpd_op.OFFSET_GAIN_PTR 6;
.CONST $cbops.cmpd_op.OFFSET_NEG_ONE 7;
.CONST $cbops.cmpd_op.OFFSET_POW2_NEG4 8;

.CONST $cbops.cmpd_op.OFFSET_EXPAND_CONSTANT 9;
.CONST $cbops.cmpd_op.OFFSET_LINEAR_CONSTANT 10;
.CONST $cbops.cmpd_op.OFFSET_COMPRESS_CONSTANT 11;
.CONST $cbops.cmpd_op.OFFSET_PEAK 12;
.CONST $cbops.cmpd_op.OFFSET_LOG_PEAK 13;
.CONST $cbops.cmpd_op.OFFSET_REGION 14;
.CONST $cbops.cmpd_op.OFFSET_INST_GAIN 15;
.CONST $cbops.cmpd_op.OFFSET_SAMPLE_COUNT 16;
.CONST $cbops.cmpd_op.STRUC_SIZE 17;
.linefile 60 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_eq.h" 1
.linefile 15 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_eq.h"
   .CONST $cbops.eq.parameter.INPUT_GAIN_EXPONENT_PTR 0;
   .CONST $cbops.eq.parameter.INPUT_GAIN_MANTISA_PTR 1;
   .CONST $cbops.eq.parameter.NUM_STAGES_FIELD 2;
   .CONST $cbops.eq.parameter.STAGES_SCALES 3;



   .CONST $cbops.eq.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.eq.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.eq.PEQ_START_FIELD 2;
.linefile 61 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_stereo_3d_enhancement.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_stereo_3d_enhancement.h"
.CONST $cbops.stereo_3d_enhancement_op.INPUT_1_START_INDEX_FIELD 0;
.CONST $cbops.stereo_3d_enhancement_op.INPUT_2_START_INDEX_FIELD 1;
.CONST $cbops.stereo_3d_enhancement_op.OUTPUT_1_START_INDEX_FIELD 2;
.CONST $cbops.stereo_3d_enhancement_op.OUTPUT_2_START_INDEX_FIELD 3;
.CONST $cbops.stereo_3d_enhancement_op.DELAY_1_STRUC_FIELD 4;
.CONST $cbops.stereo_3d_enhancement_op.DELAY_2_STRUC_FIELD 5;
.CONST $cbops.stereo_3d_enhancement_op.COEFF_STRUC_FIELD 6;
.CONST $cbops.stereo_3d_enhancement_op.REFLECTION_DELAY_SAMPLES_FIELD 7;
.CONST $cbops.stereo_3d_enhancement_op.MIX_FIELD 8;
.CONST $cbops.stereo_3d_enhancement_op.STRUC_SIZE 9;


.CONST $cbops.stereo_3d_enhancement_op.REFLECTION_DELAY 618;






.CONST $cbops.stereo_3d_enhancement_op.DELAY_BUFFER_SIZE 2048;
.linefile 62 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_volume.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_volume.h"
   .CONST $cbops.volume.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.volume.OUTPUT_START_INDEX_FIELD 1;
   .CONST $cbops.volume.FINAL_VALUE_FIELD 2;
   .CONST $cbops.volume.CURRENT_VALUE_FIELD 3;
   .CONST $cbops.volume.SAMPLES_PER_STEP_FIELD 4;
   .CONST $cbops.volume.STEP_SHIFT_FIELD 5;
   .CONST $cbops.volume.DELTA_FIELD 6;
   .CONST $cbops.volume.CURRENT_STEP_FIELD 7;
   .CONST $cbops.volume.STRUC_SIZE 8;
.linefile 63 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_peak_monitor_op.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_peak_monitor_op.h"
   .CONST $cbops.peak_monitor_op.PTR_INPUT_BUFFER_FIELD 0;
   .CONST $cbops.peak_monitor_op.PEAK_LEVEL_PTR 1;
   .CONST $cbops.peak_monitor_op.STRUC_SIZE 2;
.linefile 64 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_signal_detect.h" 1
.linefile 15 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_signal_detect.h"
    .const $cbops.signal_detect_op.LINEAR_THRESHOLD_VALUE 0;
    .const $cbops.signal_detect_op.NO_SIGNAL_TRIGGER_TIME 1;
    .const $cbops.signal_detect_op.CURRENT_MAX_VALUE 2;
    .const $cbops.signal_detect_op.SECOND_TIMER 3;
    .const $cbops.signal_detect_op.SIGNAL_STATUS 4;
    .const $cbops.signal_detect_op.SIGNAL_STATUS_MSG_ID 5;
    .const $cbops.signal_detect_op.NUM_CHANNELS 6;
    .const $cbops.signal_detect_op.FIRST_CHANNEL_INDEX 7;
    .const $cbops.signal_detect_op.STRUC_SIZE_MONO 8;
    .const $cbops.signal_detect_op.STRUC_SIZE_STEREO 9;
    .const $cbops.signal_detect_op.STRUC_SIZE_3_CHANNEL 10;
.linefile 65 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_deinterleave_mix.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_deinterleave_mix.h"
   .CONST $cbops.deinterleave_mix.INPUT_START_INDEX_FIELD 0;
   .CONST $cbops.deinterleave_mix.OUTPUT1_START_INDEX_FIELD 1;
   .CONST $cbops.deinterleave_mix.OUTPUT2_START_INDEX_FIELD 2;
   .CONST $cbops.deinterleave_mix.INPUT_INTERLEAVED_FIELD 3;
   .CONST $cbops.deinterleave_mix.STRUC_SIZE 4;
.linefile 66 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_fir_resample.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/cbops_fir_resample.h"
   .CONST $cbops.fir_resample.INPUT_INDEX_FIELD 0;
   .CONST $cbops.fir_resample.OUTPUT_INDEX_FIELD 1;
   .CONST $cbops.fir_resample.COEF_BUF_INDEX_FIELD 2;
   .CONST $cbops.fir_resample.INPUT_RATE_ADDR_FIELD 3;
   .CONST $cbops.fir_resample.OUTPUT_RATE_ADDR_FIELD 4;
   .CONST $cbops.fir_resample.HIST_BUF_FIELD 5;
   .CONST $cbops.fir_resample.CURRENT_OUTPUT_RATE_FIELD 6;
   .CONST $cbops.fir_resample.CURRENT_INPUT_RATE_FIELD 7;
   .CONST $cbops.fir_resample.CONVERT_RATIO_INT_FIELD 8;
   .CONST $cbops.fir_resample.CONVERT_RATIO_FRAC_FIELD 9;
   .CONST $cbops.fir_resample.IR_RATIO_FIELD 10;
   .CONST $cbops.fir_resample.INT_SAMPLES_LEFT_FIELD 11;
   .CONST $cbops.fir_resample.RESAMPLE_UNITY_RATIO_FIELD 12;

   .CONST $cbops.fir_resample.STRUC_SIZE 13;


   .CONST $cbops.fir_resample.HIST_LENGTH ($cbops.rate_adjustment_and_shift.SRA_COEFFS_SIZE+1);
   .CONST $cbops.fir_resample.FILTER_LENGTH $cbops.rate_adjustment_and_shift.SRA_COEFFS_SIZE;
   .CONST $cbops.fir_resample.FILTER_UPRATE $cbops.rate_adjustment_and_shift.SRA_UPRATE;
.linefile 67 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/iir_resamplev2/iir_resamplev2_header.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/multirate_operators/iir_resamplev2/iir_resamplev2_header.h"
   .CONST $iir_resamplev2.INPUT_1_START_INDEX_FIELD 0;
   .CONST $iir_resamplev2.OUTPUT_1_START_INDEX_FIELD 1;

   .CONST $iir_resamplev2.FILTER_DEFINITION_PTR_FIELD 2;
   .CONST $iir_resamplev2.INPUT_SCALE_FIELD 3;
   .CONST $iir_resamplev2.OUTPUT_SCALE_FIELD 4;

   .CONST $iir_resamplev2.INTERMEDIATE_CBUF_PTR_FIELD 5;
   .CONST $iir_resamplev2.INTERMEDIATE_CBUF_LEN_FIELD 6;

   .CONST $iir_resamplev2.PARTIAL1_FIELD 7;
   .CONST $iir_resamplev2.SAMPLE_COUNT1_FIELD 8;
   .CONST $iir_resamplev2.FIR_HISTORY_BUF1_PTR_FIELD 9;
   .CONST $iir_resamplev2.IIR_HISTORY_BUF1_PTR_FIELD 10;

   .CONST $iir_resamplev2.PARTIAL2_FIELD 11;
   .CONST $iir_resamplev2.SAMPLE_COUNT2_FIELD 12;
   .CONST $iir_resamplev2.FIR_HISTORY_BUF2_PTR_FIELD 13;
   .CONST $iir_resamplev2.IIR_HISTORY_BUF2_PTR_FIELD 14;

   .CONST $iir_resamplev2.RESET_FLAG_FIELD 15;
   .CONST $iir_resamplev2.STRUC_SIZE 16;



   .CONST $cbops.complete.iir_resamplev2.STRUC_SIZE 1;




   .CONST $IIR_RESAMPLEV2_IIR_BUFFER_SIZE 19;
   .CONST $IIR_RESAMPLEV2_FIR_BUFFER_SIZE 10;
   .CONST $IIR_RESAMPLEV2_APPENDED_BUFFER_SIZE ($IIR_RESAMPLEV2_IIR_BUFFER_SIZE+$IIR_RESAMPLEV2_FIR_BUFFER_SIZE);
   .CONST $iir_resamplev2.OBJECT_SIZE $iir_resamplev2.STRUC_SIZE + 2*$IIR_RESAMPLEV2_APPENDED_BUFFER_SIZE;

   .CONST $iir_resamplev2.OBJECT_SIZE_SNGL_STAGE $iir_resamplev2.STRUC_SIZE + $IIR_RESAMPLEV2_APPENDED_BUFFER_SIZE;
.linefile 68 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/cbops_multirate_library.h" 2
.linefile 3 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h" 1
.linefile 55 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_KALIMBA_READY 0x8000;
.linefile 87 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_CONFIGURE_PORT 0x8001;
.linefile 103 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_DATA_CONSUMED 0x8002;
.linefile 119 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_DATA_PRODUCED 0x8003;
.linefile 135 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_WARP_DAC 0x8004;
.linefile 157 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_WARP_ADC 0x8005;
.linefile 172 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_PS_READ 0x8006;
.linefile 193 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_PS_RESULT 0x8007;
.linefile 209 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_PS_FAIL 0x8008;
.linefile 231 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_FILE_ADDRESS 0x8009;
.linefile 300 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_RAND_REQ 0x800D;
.linefile 325 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_RAND_RESULT 0x800E;
.linefile 341 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_RAND_FAIL 0x800F;
.linefile 362 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_WATCHDOG_SET 0x8010;
.linefile 418 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_SCO_PARAMS 0x8014;
.linefile 445 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_SCO_PARAMS_RESULT 0x8015;
.linefile 456 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_SCO_PARAMS_FAILED 0x8016;
.linefile 468 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_SET_FRAME_LENGTH 0x8017;
.linefile 479 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_BT_ADDRESS 0x8018;
.linefile 496 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_PORT_BT_ADDRESS 0x8019;
.linefile 508 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_FRAME_LENGTH_RESPONSE 0x801A;
.linefile 527 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_WALL_CLOCK_TBTA 0x801B;
.linefile 547 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_WALL_CLOCK_RESPONSE_TBTA 0x801C;
.linefile 561 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_WALL_CLOCK_FAILED_TBTA 0x801D;
.linefile 575 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_NEXT_ACTIVITY_TIME 0x801E;
.linefile 592 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_GET_NEXT_ACTIVITY_TIME_RESPONSE 0x801F;
.linefile 606 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_NEXT_ACTIVITY_TIME_FAILED 0x8020;
.linefile 629 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_CHANGE_PIO_OWNERSHIP 0x8021;
.linefile 648 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_PIO_OWNERSHIP_RESPONSE 0x8022;


.CONST $MESSAGE_CONFIGURE_BITSERIALISER 0x8023;
.linefile 670 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_CHARGER_LIMIT_CURRENT_USE 0x8024;



.CONST $MESSAGE_CONFIGURE_QPWM 0x8025;


.CONST $MESSAGE_CONFIGURE_XIO 0x8026;
.linefile 704 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_REGISTER_COPIES_REQUEST 0x8027;
.linefile 742 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_REGISTER_COPIES_REPLY 0x8028;
.linefile 764 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_REGISTER_COPIES_ALERT 0x8029;
.linefile 773 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_BITSERIAL_BUS_SWITCH 0x802A;
.linefile 793 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_AUDIO_STREAM_RATE_EVENT 0x802B;
.linefile 809 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_SPDIF_CHNL_STS_EVENT 0x802C;
.linefile 831 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_AUDIO_CONFIGURE 0x802D;
.linefile 842 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_AUDIO_CONFIGURE_RESPONSE 0x802E;
.linefile 856 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_ACTIVATE_AUDIO 0x802F;
.linefile 867 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_ACTIVATE_AUDIO_RESPONSE 0x8030;
.linefile 881 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_SPDIF_BLOCK_START_EVENT 0x8031;
.linefile 892 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_OTP_READ_DATA 0x8032;
.linefile 904 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_OTP_READ_DATA_RESPONSE 0x8033;
.linefile 916 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_AUDIO_INFO_REQ 0x8034;
.linefile 932 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_AUDIO_INFO_RESP 0x8035;
.linefile 946 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_CLOSE_FILE_INDEX 0x8036;
.linefile 956 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_CSB_PARAMS 0x8037;
.linefile 983 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $LONG_MESSAGE_CSB_PARAMS_RESULT 0x8038;
.linefile 993 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_GET_CSB_PARAMS_FAILED 0x8039;
.linefile 1015 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_KALIMBA_READY_WITH_META 0x803a;
.linefile 1030 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_CLOSE_FILE_ADDRESS 0x803C;





.CONST $MESSAGE_BATON_BASE 0x9000;
.CONST $MESSAGE_BATON_LIMIT 0x91FF;
.linefile 1049 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_IMMEDIATE_PANIC 0xFFC0;
.linefile 1067 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/external_includes/firmware/kalimba_messages.h"
.CONST $MESSAGE_PART_BASE 0xFFF0;
.linefile 4 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h"
.CONST $FRAMESYNCLIB_VERSION 0x000002;

.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_stream_macros.h" 1
.linefile 16 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_stream_macros.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 1
.linefile 17 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_stream_macros.h" 2
.linefile 14 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_sidetone_mix_operator.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_sidetone_mix_operator.h"
   .CONST $frame_sync.sidetone_mix_op.INPUT_START_INDEX_FIELD 0;
   .CONST $frame_sync.sidetone_mix_op.OUTPUT_START_INDEX_FIELD 1;
   .CONST $frame_sync.sidetone_mix_op.SIDETONE_BUFFER_FIELD 2;
   .CONST $frame_sync.sidetone_mix_op.SIDETONE_MAX_SAMPLES_FIELD 3;
   .CONST $frame_sync.sidetone_mix_op.GAIN_FIELD 4;
   .CONST $frame_sync.sidetone_mix_op.TIMER_PERIOD_SAMPLES_FIELD 5;
   .CONST $frame_sync.sidetone_mix_op.AMOUNT_DATA_FIELD 6;
   .CONST $frame_sync.sidetone_mix_op.STRUC_SIZE 7;
.linefile 15 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_dac_sync_operator.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_dac_sync_operator.h"
.CONST $frame_sync.dac_wrap_op.INPUT_INDEX_FIELD 0;
.CONST $frame_sync.dac_wrap_op.LEFT_PORT_FIELD 1;
.CONST $frame_sync.dac_wrap_op.RIGHT_PORT_FIELD 2;
.CONST $frame_sync.dac_wrap_op.RATE_SCALE_FIELD 3;
.CONST $frame_sync.dac_wrap_op.BUFFER_ADJUST_FIELD 4;
.CONST $frame_sync.dac_wrap_op.MAX_ADVANCE_FIELD 5;
.CONST $frame_sync.dac_wrap_op.PTR_ADC_STATUS_FIELD 6;
.CONST $frame_sync.dac_wrap_op.PACKET_SIZE_PTR_FIELD 7;
.CONST $frame_sync.dac_wrap_op.COPY_LIMIT_PTR_FIELD 8;


.CONST $frame_sync.dac_wrap_op.DROP_INSERT_FIELD 9;
.CONST $frame_sync.dac_wrap_op.XFER_AMOUNT_FIELD 10;
.CONST $frame_sync.dac_wrap_op.CBUFFER_PTR_FIELD 11;
.CONST $frame_sync.dac_wrap_op.WRAP_COUNT_FIELD 12;
.CONST $frame_sync.dac_wrap_op.STRUC_SIZE 13;

.CONST $frame_sync.dac_sync_op.STRUC_PTR_FIELD 0;
.CONST $frame_sync.dac_sync_op.STRUC_SIZE 1;
.linefile 16 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_sco_copy_operator.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_sco_copy_operator.h"
   .CONST $frame_sync.sco_copy_op.INPUT_START_INDEX_FIELD 0;
   .CONST $frame_sync.sco_copy_op.OUTPUT_START_INDEX_FIELD 1;
   .CONST $frame_sync.sco_copy_op.SHIFT_AMOUNT_FIELD 2;

   .CONST $frame_sync.sco_copy_op.COPY_LIMIT_FIELD 3;

   .CONST $frame_sync.sco_copy_op.STRUC_SIZE 4;
.linefile 17 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_buffer.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_buffer.h"
.CONST $framesync_ind.CBUFFER_PTR_FIELD 0;
.CONST $framesync_ind.FRAME_PTR_FIELD 1;
.CONST $framesync_ind.CUR_FRAME_SIZE_FIELD 2;

.CONST $framesync_ind.FRAME_SIZE_FIELD 3;
.CONST $framesync_ind.JITTER_FIELD 4;
.CONST $framesync_ind.DISTRIBUTE_FUNCPTR_FIELD 5;
.CONST $framesync_ind.UPDATE_FUNCPTR_FIELD 6;
.CONST $framesync_ind.COUNTER_FIELD 7;
.CONST $framesync_ind.AMOUNT_DATA_FIELD 8;
.CONST $framesync_ind.THRESHOLD_FIELD 9;
.CONST $framesync_ind.MIN_FIELD 10;
.CONST $framesync_ind.MAX_FIELD 11;
.CONST $framesync_ind.DROP_INSERT_FIELD 12;


.CONST $framesync_ind.SYNC_POINTER_FIELD 7;
.CONST $framesync_ind.SYNC_MULTIPLIER_FIELD 8;
.CONST $framesync_ind.SYNC_AMOUNT_DATA_FIELD 9;



.CONST $framesync_ind.ENTRY_SIZE_FIELD 13;
.linefile 18 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_tsksched.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_tsksched.h"
.CONST $FRM_SCHEDULER.COUNT_FIELD 0;
.CONST $FRM_SCHEDULER.MAX_COUNT_FIELD 1;
.CONST $FRM_SCHEDULER.NUM_TASKS_FIELD 2;
.CONST $FRM_SCHEDULER.TOTAL_MIPS_FIELD 3;
.CONST $FRM_SCHEDULER.SEND_MIPS_FIELD 4;
.CONST $FRM_SCHEDULER.TOTALTM_FIELD 5;
.CONST $FRM_SCHEDULER.TOTALSND_FIELD 6;
.CONST $FRM_SCHEDULER.TIMER_FIELD 7;
.CONST $FRM_SCHEDULER.TRIGGER_FIELD 8;
.CONST $FRM_SCHEDULER.TASKS_FIELD 9;
.linefile 19 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_hw_warp_operator.h" 1
.linefile 13 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_hw_warp_operator.h"
.CONST $frame_sync.hw_warp_op.PORT_OFFSET 0;
.CONST $frame_sync.hw_warp_op.WHICH_PORTS_OFFSET 1;
.CONST $frame_sync.hw_warp_op.TARGET_RATE_OFFSET 2;
.CONST $frame_sync.hw_warp_op.PERIODS_PER_SECOND_OFFSET 3;
.CONST $frame_sync.hw_warp_op.COLLECT_SECONDS_OFFSET 4;
.CONST $frame_sync.hw_warp_op.ENABLE_DITHER_OFFSET 5;

.CONST $frame_sync.hw_warp_op.ACCUMULATOR_OFFSET 6;
.CONST $frame_sync.hw_warp_op.PERIOD_COUNTER_OFFSET 7;
.CONST $frame_sync.hw_warp_op.LAST_WARP_OFFSET 8;

.CONST $frame_sync.hw_warp_op.STRUC_SIZE 9;
.linefile 20 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_library.h" 2


.CONST $frame_sync.frame_process.AMT_RDY_BUFFER_PTR_FIELD 0;
.CONST $frame_sync.frame_process.MIN_AMOUNT_READY_FIELD 1;
.CONST $frame_sync.frame_process.NUM_OUTPUT_RATE_OBJECTS_FIELD 2;
.CONST $frame_sync.frame_process.NUM_RATE_OBJECTS_FIELD 3;
.CONST $frame_sync.frame_process.STRUC_SIZE 4;


.CONST $frame_sync.frame_process.FIRST_CBUFFER_STRUC_FIELD 4;
.linefile 5 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_codec.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_codec.h"
.CONST $sco_pkt_handler.SCO_PORT_FIELD 0;
.CONST $sco_pkt_handler.SCO_PAYLOAD_FIELD 1;
.CONST $sco_pkt_handler.INPUT_PTR_FIELD 2;
.CONST $sco_pkt_handler.OUTPUT_PTR_FIELD 3;
.CONST $sco_pkt_handler.ENABLE_FIELD 4;
.CONST $sco_pkt_handler.CONFIG_FIELD 5;
.CONST $sco_pkt_handler.STAT_LIMIT_FIELD 6;
.CONST $sco_pkt_handler.PACKET_IN_LEN_FIELD 7;
.CONST $sco_pkt_handler.PACKET_OUT_LEN_FIELD 8;
.CONST $sco_pkt_handler.DECODER_PTR 9;
.CONST $sco_pkt_handler.PLC_PROCESS_PTR 10;
.CONST $sco_pkt_handler.PLC_RESET_PTR 11;
.CONST $sco_pkt_handler.BFI_FIELD 12;
.CONST $sco_pkt_handler.PACKET_LOSS_FIELD 13;
.CONST $sco_pkt_handler.INV_STAT_LIMIT_FIELD 14;
.CONST $sco_pkt_handler.PACKET_COUNT_FIELD 15;
.CONST $sco_pkt_handler.BAD_PACKET_COUNT_FIELD 16;
.CONST $sco_pkt_handler.PLC_DATA_PTR_FIELD 17;

.CONST $sco_pkt_handler.SCO_OUT_PORT_FIELD 18;
.CONST $sco_pkt_handler.SCO_OUT_SHIFT_FIELD 19;
.CONST $sco_pkt_handler.SCO_OUT_BUFFER_FIELD 20;
.CONST $sco_pkt_handler.SCO_OUT_PKTSIZE_FIELD 21;
.CONST $sco_pkt_handler.SCO_PARAM_TESCO_FIELD 22;
.CONST $sco_pkt_handler.SCO_PARAM_SLOT_LS_FIELD 23;
.CONST $sco_pkt_handler.SCO_NEW_PARAMS_FLAG 24;
.CONST $sco_pkt_handler.JITTER_PTR_FIELD 25;


.CONST $sco_pkt_handler.ENCODER_BUFFER_FIELD 26;
.CONST $sco_pkt_handler.ENCODER_INPUT_SIZE_FIELD 27;
.CONST $sco_pkt_handler.ENCODER_OUTPUT_SIZE_FIELD 28;
.CONST $sco_pkt_handler.ENCODER_SETUP_FUNC_FIELD 29;
.CONST $sco_pkt_handler.ENCODER_PROC_FUNC_FIELD 30;

.CONST $sco_pkt_handler.STRUC_SIZE 31;


.CONST $sco_decoder.VALIDATE_FUNC 0;
.CONST $sco_decoder.DECODE_FUNC 1;
.CONST $sco_decoder.RESET_FUNC 2;
.CONST $sco_decoder.DATA_PTR 3;
.CONST $sco_decoder.THRESHOLD 4;
.CONST $sco_decoder.STRUC_SIZE 5;
.linefile 6 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/usbio.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/usbio.h"
.CONST $USB_STALL_CNT_THRESH 7;


.CONST $frame_sync.SYNC_MASK 0x7f;


.CONST $frame_sync.USB_IN_STEREO_COPY_SOURCE_FIELD 0;
.CONST $frame_sync.USB_IN_STEREO_COPY_LEFT_SINK_FIELD 1;
.CONST $frame_sync.USB_IN_STEREO_COPY_RIGHT_SINK_FIELD 2;
.CONST $frame_sync.USB_IN_STEREO_COPY_PACKET_LENGTH_FIELD 3;
.CONST $frame_sync.USB_IN_STEREO_COPY_SHIFT_AMOUNT_FIELD 4;
.CONST $frame_sync.USB_IN_STEREO_COPY_LAST_HEADER_FIELD 5;
.CONST $frame_sync.USB_IN_STEREO_PACKET_COUNT_MODULO_FIELD 6;
.CONST $frame_sync.USB_IN_STEREO_STATE_FIELD 7;
.CONST $frame_sync.USB_IN_STEREO_PACKET_COUNTER_FIELD 8;
.CONST $frame_sync.USB_IN_STEREO_COPY_RETRY_FIELD 9;
.CONST $frame_sync.USB_IN_STEREO_COPY_STRUC_SIZE 10;



.CONST $frame_sync.USB_IN_MONO_COPY_SOURCE_FIELD 0;
.CONST $frame_sync.USB_IN_MONO_COPY_SINK_FIELD 1;
.CONST $frame_sync.USB_IN_MONO_COPY_PACKET_LENGTH_FIELD 2;
.CONST $frame_sync.USB_IN_MONO_COPY_SHIFT_AMOUNT_FIELD 3;
.CONST $frame_sync.USB_IN_MONO_COPY_LAST_HEADER_FIELD 4;
.CONST $frame_sync.USB_IN_MONO_PACKET_COUNT_MODULO_FIELD 5;
.CONST $frame_sync.USB_IN_MONO_STATE_FIELD 6;
.CONST $frame_sync.USB_IN_MONO_PACKET_COUNTER_FIELD 7;
.CONST $frame_sync.USB_IN_MONO_COPY_RETRY_FIELD 8;
.CONST $frame_sync.USB_IN_MONO_COPY_STRUC_SIZE 9;



.CONST $frame_sync.USB_OUT_STEREO_LEFT_SOURCE_FIELD 0;
.CONST $frame_sync.USB_OUT_STEREO_RIGHT_SOURCE_FIELD 1;
.CONST $frame_sync.USB_OUT_STEREO_SINK_FIELD 2;
.CONST $frame_sync.USB_OUT_STEREO_SHIFT_AMOUNT_FIELD 3;
.CONST $frame_sync.USB_OUT_STEREO_TRANSFER_PER_PERIOD_FIELD 4;
.CONST $frame_sync.USB_OUT_STEREO_STALL_CNT_FIELD 5;
.CONST $frame_sync.USB_OUT_STEREO_STRUC_SIZE 6;



.CONST $frame_sync.USB_OUT_MONO_SOURCE_FIELD 0;
.CONST $frame_sync.USB_OUT_MONO_SINK_FIELD 1;
.CONST $frame_sync.USB_OUT_MONO_SHIFT_AMOUNT_FIELD 2;
.CONST $frame_sync.USB_OUT_MONO_TRANSFER_PER_PERIOD_FIELD 3;
.CONST $frame_sync.USB_OUT_MONO_STALL_CNT_FIELD 4;
.CONST $frame_sync.USB_OUT_MONO_STRUC_SIZE 5;

.CONST $frame_sync.IDLE_STATE 0;
.CONST $frame_sync.SYNCING_A_STATE 1;
.CONST $frame_sync.SYNCING_B_STATE 2;
.CONST $frame_sync.SYNCED_STATE 3;
.linefile 7 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/plc100_library.h" 1
.linefile 21 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/plc100_library.h"
   .CONST $PLC100_VERSION 0x010000;
.linefile 30 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/plc100_library.h"
   .CONST $plc100.SPEECH_BUF_START_ADDR_FIELD 0;

   .CONST $plc100.SPEECH_BUF_PTR_FIELD 1;


   .CONST $plc100.OLA_BUF_PTR_FIELD 2;


   .CONST $plc100.OUTPUT_PTR_FIELD 3;


   .CONST $plc100.CONSTS_FIELD 4;


   .CONST $plc100.ATTENUATION_FIELD 5;


   .CONST $plc100.PER_THRESHOLD_FIELD 6;
   .CONST $plc100.PACKET_LEN_FIELD 7;
   .CONST $plc100.BFI_FIELD 8;
   .CONST $plc100.BFI1_FIELD 9;
   .CONST $plc100.BFI_CUR_FIELD 10;
   .CONST $plc100.PER_FIELD 11;
   .CONST $plc100.PITCH_FIELD 12;
   .CONST $plc100.BFI_PREV_FIELD 13;
   .CONST $plc100.HARM_FIELD 14;
   .CONST $plc100.TONALITY_FIELD 15;
   .CONST $plc100.LOOP_LIMIT_FIELD 16;
   .CONST $plc100.SUB_PACKET_LEN_FIELD 17;
   .CONST $plc100.LOOP_COUNTER_FIELD 18;

   .CONST $plc100.STRUC_SIZE 19;


   .CONST $plc100.consts.SPEECH_BUF_LEN_FIELD 0;
   .CONST $plc100.consts.OLA_LEN_FIELD 1;
   .CONST $plc100.consts.RANGE_FIELD 2;
   .CONST $plc100.consts.MIN_DELAY_FIELD 3;
   .CONST $plc100.consts.MAX_DELAY_FIELD 4;
   .CONST $plc100.consts.PER_TC_INV_FIELD 5;
   .CONST $plc100.consts.OLA_WIN_PTR_FIELD 6;
   .CONST $plc100.consts.STRUC_SIZE 7;






   .CONST $plc100.ONEQ16 0x010000;

   .CONST $plc100.M_THRESH 0x11EC;

   .CONST $plc100.HARM_TONETHRESH 0x1C000;
   .CONST $plc100.MAX_PACKET_LEN 60;
   .CONST $plc100.ATT_THRESH 0.95;

   .CONST $plc100.HARM_THRESHOLD 0xB333;
   .CONST $plc100.XCORR_THRESH 0x733333;


   .CONST $plc100.INITIAL_ATTENUATION 0.8;



   .CONST $plc100.BITERROR_PACKET 1;

   .CONST $plc100.MISSED_PACKET 3;





   .CONST $plc100.MIN_DELAY_NB 54;
   .CONST $plc100.MAX_DELAY_NB 108;
   .CONST $plc100.OLA_LEN_NB 10;
   .CONST $plc100.SP_BUF_LEN_NB 226;
   .CONST $plc100.RANGE_NB 4;
   .CONST $plc100.PER_TC_INV_NB 0x6666;

   .CONST $plc100.MIN_DELAY_WB 107;
   .CONST $plc100.MAX_DELAY_WB 214;
   .CONST $plc100.OLA_LEN_WB 24;
   .CONST $plc100.SP_BUF_LEN_WB 452;
   .CONST $plc100.RANGE_WB 8;
   .CONST $plc100.PER_TC_INV_WB 0x3333;
.linefile 8 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/one_mic_example.h" 1
.linefile 12 "vcp_8k_wired_to_24k_wired/one_mic_example.h"
.CONST $one_mic_example.REINITIALIZE 1;
.CONST $one_mic_example.VMMSG.SETMODE 4;
.CONST $one_mic_example.VMMSG.READY 5;
.CONST $one_mic_example.MESSAGE_REM_BT_ADDRESS 0x2001;


.CONST $one_mic_example.SYSMODE.PASSTHRU 0;


.CONST $one_mic_example.NUM_SAMPLES_PER_FRAME 60;
.CONST $one_mic_example.JITTER 8;

.CONST $SAMPLE_RATE 8000;
.CONST $BLOCK_SIZE 60;

.CONST $BUFFER_SCALING 4;
.CONST $TONE_BUFFER_SIZE ($BLOCK_SIZE * 2);
.CONST $TWO_MIC_EXAMPLE_BUFFER_SIZE $BLOCK_SIZE;
.linefile 9 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_stream_macros.h" 1
.linefile 10 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/flash.h" 1
.linefile 11 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/stream_copy.h" 1
.linefile 12 "vcp_8k_wired_to_24k_wired/stream_copy.h"
.CONST $stream_copy.INPUT_PTR_BUFFER_FIELD 0;
.CONST $stream_copy.OUTPUT_PTR_BUFFER_FIELD 1;
.CONST $stream_copy.OFFSET_INPUT_REF_PTR 2;
.CONST $stream_copy.OFFSET_PTR_REF_STRUC 3;
.CONST $stream_copy.STRUC_SIZE 4;
.linefile 12 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/sbc_library.h" 1
.linefile 9 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/sbc_library.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/sbc.h" 1
.linefile 31 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/sbc.h"
   .CONST $sbc.MAX_AUDIO_FRAME_SIZE_IN_WORDS 128;
   .CONST $sbc.MAX_SBC_FRAME_SIZE_IN_BYTES 512;
   .CONST $sbc.MIN_SBC_FRAME_SIZE_IN_BYTES 20;
   .CONST $sbc.CAN_IDLE 0;
   .CONST $sbc.DONT_IDLE 1;
   .CONST $sbc.WBS_SBC_FRAME_LENGTH_IN_BYTES 62;
   .CONST $sbc.WBS_SBC_FRAME_LENGTH_IN_WORDS 31;
   .CONST $sbc.SBC_NOT_SYNC 99;



   .CONST $sbcdec.STATE_STRUC_SIZE 326;
   .CONST $sbcend.STATE_STRUC_SIZE 172;



    .CONST $sbc.mem.AUDIO_SAMPLE_JS_FIELD 0;
    .CONST $sbc.mem.ANALYSIS_COEFS_M8_FIELD 1;
    .CONST $sbc.mem.ANALYSIS_COEFS_M4_FIELD 2;
    .CONST $sbc.mem.ANALYSIS_XCH1_FIELD 3;
    .CONST $sbc.mem.ANALYSIS_XCH2_FIELD 4;
    .CONST $sbc.mem.ANALYSIS_Y_FIELD 5;
    .CONST $sbc.mem.LEVEL_COEFS_FIELD 6;
    .CONST $sbc.mem.PRE_POST_PROC_STRUC_FIELD 7;
    .CONST $sbc.mem.ENC_SETTING_NROF_SUBBANDS_FIELD 8;
    .CONST $sbc.mem.ENC_SETTING_NROF_BLOCKS_FIELD 9;
    .CONST $sbc.mem.ENC_SETTING_SAMPLING_FREQ_FIELD 10;
    .CONST $sbc.mem.ENC_SETTING_CHANNEL_MODE_FIELD 11;
    .CONST $sbc.mem.ENC_SETTING_ALLOCATION_METHOD_FIELD 12;
    .CONST $sbc.mem.ENC_SETTING_BITPOOL_FIELD 13;
    .CONST $sbc.mem.ENC_SETTING_FORCE_WORD_ALIGN_FIELD 14;
    .CONST $sbc.mem.PUT_NEXTWORD_FIELD 15;
    .CONST $sbc.mem.PUT_BITPOS_FIELD 16;
    .CONST $sbc.mem.ANALYSIS_XCH1PTR_FIELD 17;
    .CONST $sbc.mem.ANALYSIS_XCH2PTR_FIELD 18;
    .CONST $sbc.mem.WBS_SEND_FRAME_COUNTER_FIELD 19;

    .CONST $sbc.mem.AUDIO_SAMPLE_FIELD 20;
    .CONST $sbc.mem.WIN_COEFS_M8_FIELD 21;
    .CONST $sbc.mem.WIN_COEFS_M4_FIELD 22;
    .CONST $sbc.mem.LOUDNESS_OFFSET_FIELD 23;
    .CONST $sbc.mem.SCALE_FACTOR_FIELD 24;
    .CONST $sbc.mem.SCALE_FACTOR_JS_FIELD 25;
    .CONST $sbc.mem.BITNEED_FIELD 26;
    .CONST $sbc.mem.BITS_FIELD 27;
    .CONST $sbc.mem.SAMPLING_FREQ_FIELD 28;
    .CONST $sbc.mem.NROF_BLOCKS_FIELD 29;
    .CONST $sbc.mem.CHANNEL_MODE_FIELD 30;
    .CONST $sbc.mem.NROF_CHANNELS_FIELD 31;
    .CONST $sbc.mem.ALLOCATION_METHOD_FIELD 32;
    .CONST $sbc.mem.NROF_SUBBANDS_FIELD 33;
    .CONST $sbc.mem.BITPOOL_FIELD 34;
    .CONST $sbc.mem.FRAMECRC_FIELD 35;
    .CONST $sbc.mem.CRC_CHECKSUM_FIELD 36;
    .CONST $sbc.mem.FORCE_WORD_ALIGN_FIELD 37;
    .CONST $sbc.mem.JOIN_FIELD 38;
    .CONST $sbc.mem.JOIN_1_FIELD 39;
    .CONST $sbc.mem.JOIN_2_FIELD 40;
    .CONST $sbc.mem.JOIN_3_FIELD 41;
    .CONST $sbc.mem.JOIN_4_FIELD 42;
    .CONST $sbc.mem.JOIN_5_FIELD 43;
    .CONST $sbc.mem.JOIN_6_FIELD 44;
    .CONST $sbc.mem.JOIN_7_FIELD 45;
    .CONST $sbcenc.mem.STRUC_SIZE 46;

    .CONST $sbc.mem.SYNTHESIS_COEFS_M8_FIELD 46;
    .CONST $sbc.mem.SYNTHESIS_COEFS_M4_FIELD 47;
    .CONST $sbc.mem.LEVELRECIP_COEFS_FIELD 48;
    .CONST $sbc.mem.BITMASK_LOOKUP_FIELD 49;
    .CONST $sbc.mem.SYNTHESIS_VCH1_FIELD 50;
    .CONST $sbc.mem.SYNTHESIS_VCH2_FIELD 51;
    .CONST $sbc.mem.CONVERT_TO_MONO_FIELD 52;
    .CONST $sbc.mem.FRAME_UNDERFLOW_FIELD 53;
    .CONST $sbc.mem.FRAME_CORRUPT_FIELD 54;
    .CONST $sbc.mem.NUM_BYTES_AVAILABLE_FIELD 55;
    .CONST $sbc.mem.WBS_SBC_FRAME_OK_FIELD 56;
    .CONST $sbc.mem.CUR_FRAME_LENGTH_FIELD 57;
    .CONST $sbc.mem.RETURN_ON_CORRUPT_FRAME_FIELD 58;
    .CONST $sbc.mem.GET_BITPOS_FIELD 59;
    .CONST $sbc.mem.SYNTHESIS_VCH1PTR_FIELD 60;
    .CONST $sbc.mem.SYNTHESIS_VCH2PTR_FIELD 61;
    .CONST $sbc.mem.WBS_FRAME_BUFFER_PTR_FIELD 62;
    .CONST $sbc.mem.WBS_SYNC_FIELD 63;
    .CONST $sbc.mem.WBS_BYTES_IN_FRAME_BUFFER_FIELD 64;
    .CONST $sbc.mem.WBS_STICKY_BFI_FIELD 65;
    .CONST $sbc.mem.WBS_PAYLOAD_ALIGN_FIELD 66;
    .CONST $sbc.mem.TIMESTAMP_T1_FIELD 67;
    .CONST $sbc.mem.TIMESTAMP_T2_FIELD 68;
    .CONST $sbc.mem.FRAME_SYNC_SEARCH_DISABLE 69;


    .CONST $sbc.mem.STRUC_SIZE 70;
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/sbc_library.h" 2
.linefile 13 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/codec_library.h" 1
.linefile 10 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/codec_library.h"
.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/core_library.h" 1
.linefile 11 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/codec_library.h" 2






   .CONST $codec.NORMAL_DECODE 0;
   .CONST $codec.NO_OUTPUT_DECODE 1;
   .CONST $codec.GOBBLE_DECODE 2;

   .CONST $codec.SUCCESS 0;
   .CONST $codec.NOT_ENOUGH_INPUT_DATA 1;
   .CONST $codec.NOT_ENOUGH_OUTPUT_SPACE 2;
   .CONST $codec.ERROR 3;
   .CONST $codec.EOF 4;
   .CONST $codec.FRAME_CORRUPT 5;
   .CONST $codec.SYNC_ERROR 6;
   .CONST $codec.FRAME_CRC_ERROR 7;

   .CONST $codec.ENCODER_OUT_BUFFER_FIELD 0;
   .CONST $codec.ENCODER_IN_LEFT_BUFFER_FIELD 1;
   .CONST $codec.ENCODER_IN_RIGHT_BUFFER_FIELD 2;
   .CONST $codec.ENCODER_MODE_FIELD 3;
   .CONST $codec.ENCODER_DATA_OBJECT_FIELD 4;
   .CONST $codec.ENCODER_STRUC_SIZE 5;

   .CONST $codec.DECODER_IN_BUFFER_FIELD 0;
   .CONST $codec.DECODER_OUT_LEFT_BUFFER_FIELD 1;
   .CONST $codec.DECODER_OUT_RIGHT_BUFFER_FIELD 2;
   .CONST $codec.DECODER_MODE_FIELD 3;
   .CONST $codec.DECODER_NUM_OUTPUT_SAMPLES_FIELD 4;
   .CONST $codec.DECODER_DATA_OBJECT_FIELD 5;
   .CONST $codec.TWS_CALLBACK_FIELD 6;
   .CONST $codec.DECODER_STRUC_SIZE 7;

   .CONST $codec.DECRYPTER_IN_BUFFER_FIELD 0;
   .CONST $codec.DECRYPTER_OUT_BUFFER_FIELD 1;
   .CONST $codec.DECRYPTER_EXTRA_STRUC_PTR_FIELD 2;
   .CONST $codec.DECRYPTER_STRUC_SIZE 3;

   .CONST $codec.STREAM_CAN_IDLE 0;
   .CONST $codec.STREAM_DONT_IDLE 1;


   .CONST $codec.FRAME_DECODE 0;
   .CONST $codec.INIT_DECODER 1;
   .CONST $codec.RESET_DECODER 2;
   .CONST $codec.SILENCE_DECODER 3;
   .CONST $codec.SUSPEND_DECODER 4;
   .CONST $codec.RESUME_DECODER 5;
   .CONST $codec.STORE_BOUNDARY_SNAPSHOT 6;
   .CONST $codec.RESTORE_BOUNDARY_SNAPSHOT 7;
   .CONST $codec.FAST_SKIP 8;
   .CONST $codec.SET_SKIP_FUNCTION 9;
   .CONST $codec.SET_AVERAGE_BITRATE 10;
   .CONST $codec.SET_FILE_TYPE 11;
   .CONST $codec.DECRYPTER_SET_DECODER 12;
   .CONST $codec.DECRYPTER_SET_PARAMETERS 13;




   .CONST $codec.stream_encode.ADDR_FIELD 0;
   .CONST $codec.stream_encode.RESET_ADDR_FIELD 1;
   .CONST $codec.stream_encode.ENCODER_STRUC_FIELD $codec.stream_encode.RESET_ADDR_FIELD + 1;

   .CONST $codec.stream_encode.STATE_FIELD $codec.stream_encode.ENCODER_STRUC_FIELD + $codec.ENCODER_STRUC_SIZE;
   .CONST $codec.stream_encode.MEDIA_HDR_ADDR_FIELD $codec.stream_encode.STATE_FIELD + 1;
   .CONST $codec.stream_encode.STRUC_SIZE $codec.stream_encode.MEDIA_HDR_ADDR_FIELD + 1;


   .CONST $codec.stream_encode.OUT_BUFFER_FIELD $codec.stream_encode.ENCODER_STRUC_FIELD + $codec.ENCODER_OUT_BUFFER_FIELD;
   .CONST $codec.stream_encode.IN_LEFT_BUFFER_FIELD $codec.stream_encode.ENCODER_STRUC_FIELD + $codec.ENCODER_IN_LEFT_BUFFER_FIELD;
   .CONST $codec.stream_encode.IN_RIGHT_BUFFER_FIELD $codec.stream_encode.ENCODER_STRUC_FIELD + $codec.ENCODER_IN_RIGHT_BUFFER_FIELD;
   .CONST $codec.stream_encode.MODE_FIELD $codec.stream_encode.ENCODER_STRUC_FIELD + $codec.ENCODER_MODE_FIELD;






   .CONST $codec.SBC_RTP_AND_PAYLOAD_HEADER_SIZE 13;
   .CONST $codec.MP3_RTP_AND_PAYLOAD_HEADER_SIZE 16;
   .CONST $codec.APTX_RTP_AND_PAYLOAD_HEADER_SIZE 0;


   .CONST $codec.media_header.WRITE_HDR_FIELD 0;
   .CONST $codec.media_header.RTP_SEQUENCE_NUM_FIELD 1;
   .CONST $codec.media_header.RTP_TIMESTAMP_MS_FIELD 2;
   .CONST $codec.media_header.RTP_TIMESTAMP_LS_FIELD 3;
   .CONST $codec.media_header.FRAME_COUNT_FIELD 4;
   .CONST $codec.media_header.SAMPLES_PER_FRAME 5;
   .CONST $codec.media_header.PUT_BITS_ADDR_FIELD 6;
   .CONST $codec.media_header.GET_ENCODED_FRAME_INFO 7;
   .CONST $codec.media_header.NUM_FRAMES_FIELD 8;
   .CONST $codec.media_header.L2CAP_ATU_SIZE_FIELD 9;
   .CONST $codec.media_header.SHUNT_FRAME_BYTE_COUNT_FIELD 10;
   .CONST $codec.media_header.RTP_AND_PAYLOAD_HEADER_SIZE_FIELD 11;
   .CONST $codec.media_header.FASTSTREAM_ENABLED_FIELD 12;
   .CONST $codec.media_header.MEDIA_HDR_STRUC_SIZE $codec.media_header.FASTSTREAM_ENABLED_FIELD + 1;

   .CONST $codec.stream_encode.STATE_STOPPED 0;
   .CONST $codec.stream_encode.STATE_STREAMING 1;
   .CONST $codec.stream_encode.STATE_MASK 1;

   .CONST $codec.stream_decode.ADDR_FIELD 0;
   .CONST $codec.stream_decode.RESET_ADDR_FIELD 1;
   .CONST $codec.stream_decode.SILENCE_ADDR_FIELD 2;
   .CONST $codec.stream_decode.DECODER_STRUC_FIELD $codec.stream_decode.SILENCE_ADDR_FIELD + 1;

   .CONST $codec.stream_decode.COMFORT_NOISE_GAIN_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 0;
   .CONST $codec.stream_decode.GOOD_WORKING_BUFLEVEL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 1;
   .CONST $codec.stream_decode.POORLINK_DETECT_BUFLEVEL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 2;
   .CONST $codec.stream_decode.POORLINK_PERIOD_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 3;
   .CONST $codec.stream_decode.PLAYING_ZERO_DATARATE_PERIOD_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 4;
   .CONST $codec.stream_decode.BUFFERING_ZERO_DATARATE_PERIOD_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 5;
   .CONST $codec.stream_decode.POORLINK_DETECT_TABLE_ADDR_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 6;
   .CONST $codec.stream_decode.POORLINK_DETECT_TABLE_SIZE_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 7;
   .CONST $codec.stream_decode.WARP_RATE_HIGH_COEF_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 8;
   .CONST $codec.stream_decode.WARP_RATE_LOW_COEF_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 9;
   .CONST $codec.stream_decode.WARP_RATE_TRANSITION_LEVEL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 10;
   .CONST $codec.stream_decode.POORLINK_DETECT_TABLE_OFFSET_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 11;
   .CONST $codec.stream_decode.RAND_LAST_VAL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 12;
   .CONST $codec.stream_decode.STATE_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 13;
   .CONST $codec.stream_decode.POORLINK_ENDTIME_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 14;
   .CONST $codec.stream_decode.ZERO_DATARATE_ENDTIME_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 15;
   .CONST $codec.stream_decode.PLAYING_STARTTIME_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 16;
   .CONST $codec.stream_decode.PREV_WRITE_PTR_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 17;
   .CONST $codec.stream_decode.FAST_AVERAGE_BUFLEVEL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 18;
   .CONST $codec.stream_decode.SLOW_AVERAGE_BUFLEVEL_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 19;
   .CONST $codec.stream_decode.SLOW_AVERAGE_SAMPLE_TIME_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 20;
   .CONST $codec.stream_decode.WARP_TARGET_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_STRUC_SIZE + 21;
   .CONST $codec.stream_decode.STRUC_SIZE $codec.stream_decode.WARP_TARGET_FIELD + 1;


   .CONST $codec.stream_decode.IN_BUFFER_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_IN_BUFFER_FIELD;
   .CONST $codec.stream_decode.OUT_LEFT_BUFFER_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_OUT_LEFT_BUFFER_FIELD;
   .CONST $codec.stream_decode.OUT_RIGHT_BUFFER_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_OUT_RIGHT_BUFFER_FIELD;
   .CONST $codec.stream_decode.MODE_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_MODE_FIELD;
   .CONST $codec.stream_decode.NUM_OUTPUT_SAMPLES_FIELD $codec.stream_decode.DECODER_STRUC_FIELD + $codec.DECODER_NUM_OUTPUT_SAMPLES_FIELD;



   .CONST $codec.stream_decode.STATE_BUFFERING 0;
   .CONST $codec.stream_decode.STATE_PLAYING 1;
   .CONST $codec.stream_decode.STATE_MASK 1;

   .CONST $codec.stream_decode_sync.CONDITION_READ_WALL_CLOCK 2;
   .CONST $codec.stream_decode_sync.CONDITION_DECODE_FRAME 4;
   .CONST $codec.stream_decode_sync.CONDITION_INSERT_SAMPLES 8;

   .CONST $codec.stream_decode.CONDITION_POORLINK 2;
   .CONST $codec.stream_decode.CONDITION_DETECT_POORLINK_ENABLE 4;
   .CONST $codec.stream_decode.CONDITION_ZERO_DATARATE 8;
   .CONST $codec.stream_decode.CONDITION_STOPPING 16;

   .CONST $codec.stream_decode.FAST_AVERAGE_SHIFT_CONST -6;
   .CONST $codec.stream_decode.SLOW_AVERAGE_SHIFT_CONST -2;
   .CONST $codec.stream_decode.SLOW_AVERAGE_SAMPLE_PERIOD 50000;
.linefile 178 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/codec_library.h"
   .CONST $codec.stream_relay.GET_FRAME_INFO_ADDR_FIELD 0;
   .CONST $codec.stream_relay.IN_BUFFER_FIELD 1;
   .CONST $codec.stream_relay.LOCAL_RELAY_BUFFER_FIELD 2;
   .CONST $codec.stream_relay.REMOTE_RELAY_BUFFER_FIELD 3;
   .CONST $codec.stream_relay.BUFFER_DELAY_IN_US_FIELD 4;
   .CONST $codec.stream_relay.WARP_RATE_COEF_FIELD 5;
   .CONST $codec.stream_relay.NUM_AUDIO_SAMPLES_CONSUMED_PNTR_FIELD 6;
   .CONST $codec.stream_relay.WALL_CLOCK_STRUC_PNTR_FIELD 7;
   .CONST $codec.stream_relay.NUM_MICRO_SECS_PER_1024_SAMPLES_FIELD 8;
   .CONST $codec.stream_relay.PREVIOUS_AUDIO_FRAME_LENGTH_FIELD 9;
   .CONST $codec.stream_relay.SLOW_AVERAGE_BUFLEVEL_FIELD 10;
   .CONST $codec.stream_relay.SLOW_AVERAGE_SAMPLE_TIME_FIELD 11;
   .CONST $codec.stream_relay.STATE_FIELD 12;
   .CONST $codec.stream_relay.TIME_TO_PLAY_FIELD 13;
   .CONST $codec.stream_relay.NUM_AUDIO_SAMPLES_IN_BUFFER_FIELD 14;
   .CONST $codec.stream_relay.GOOD_WORKING_BUFLEVEL_FIELD 15;
   .CONST $codec.stream_relay.STRUC_SIZE 16;

   .CONST $codec.stream_relay.SLOW_AVERAGE_SAMPLE_PERIOD 50000;
   .CONST $codec.stream_relay.SLOW_AVERAGE_SHIFT_CONST -2;

   .CONST $codec.stream_relay.STATE_BUFFERING 0;
   .CONST $codec.stream_relay.STATE_PLAYING 1;



   .CONST $codec.stream_decode_sync.ADDR_FIELD 0;
   .CONST $codec.stream_decode_sync.RESET_ADDR_FIELD 1;
   .CONST $codec.stream_decode_sync.SILENCE_ADDR_FIELD 2;
   .CONST $codec.stream_decode_sync.GET_FRAME_INFO_ADDR_FIELD 3;
   .CONST $codec.stream_decode_sync.LEFT_DAC_PORT_FIELD 4;
   .CONST $codec.stream_decode_sync.RIGHT_DAC_PORT_FIELD 5;
   .CONST $codec.stream_decode_sync.IN_BUFFER_FIELD 6;
   .CONST $codec.stream_decode_sync.OUT_LEFT_BUFFER_FIELD 7;
   .CONST $codec.stream_decode_sync.OUT_RIGHT_BUFFER_FIELD 8;
   .CONST $codec.stream_decode_sync.MODE_FIELD 9;
   .CONST $codec.stream_decode_sync.NUM_OUTPUT_SAMPLES_FIELD 10;
   .CONST $codec.stream_decode_sync.COMFORT_NOISE_GAIN_FIELD 11;
   .CONST $codec.stream_decode_sync.DELAY_TO_WARP_COEF_FIELD 12;
   .CONST $codec.stream_decode_sync.MAX_PLAY_TIME_OFFSET_IN_US_FIELD 13;
   .CONST $codec.stream_decode_sync.GENERATE_SILENCE_THRESHOLD_FIELD 14;
   .CONST $codec.stream_decode_sync.AMOUNT_OF_SILENCE_TO_GENERATE_FIELD 15;
   .CONST $codec.stream_decode_sync.CURRENT_MODE_FIELD 16;
   .CONST $codec.stream_decode_sync.DECODER_MODE_FIELD 17;
   .CONST $codec.stream_decode_sync.FRAME_PLAY_TIME_FIELD 18;
   .CONST $codec.stream_decode_sync.NUM_MICRO_SECS_PER_1024_SAMPLES_FIELD 19;
   .CONST $codec.stream_decode_sync.NUM_SAMPLES_PER_US_FIELD 20;
   .CONST $codec.stream_decode_sync.PADDING_BYTE_FIELD 21;
   .CONST $codec.stream_decode_sync.RAND_LAST_VAL_FIELD 22;
   .CONST $codec.stream_decode_sync.REQUESTED_WARP_FIELD 23;
   .CONST $codec.stream_decode_sync.STREAMING_FIELD 24;
   .CONST $codec.stream_decode_sync.AUDIO_SAMPLES_CONSUMED_FIELD 25;
   .CONST $codec.stream_decode_sync.WALL_CLOCK_STRUC_FIELD 26;
   .CONST $codec.stream_decode_sync.STRUC_SIZE ($codec.stream_decode_sync.WALL_CLOCK_STRUC_FIELD + $wall_clock.STRUC_SIZE);

   .CONST $codec.stream_decode_sync.STREAMING_STOPPED 0;
   .CONST $codec.stream_decode_sync.STREAMING_PLAYING 1;



   .CONST $codec.av_encode.ADDR_FIELD 0;
   .CONST $codec.av_encode.RESET_ADDR_FIELD $codec.av_encode.ADDR_FIELD + 1;

   .CONST $codec.av_encode.ENCODER_STRUC_FIELD $codec.av_encode.RESET_ADDR_FIELD + 1;
   .CONST $codec.av_encode.OUT_BUFFER_FIELD $codec.av_encode.ENCODER_STRUC_FIELD;
   .CONST $codec.av_encode.IN_LEFT_BUFFER_FIELD $codec.av_encode.OUT_BUFFER_FIELD + 1;
   .CONST $codec.av_encode.IN_RIGHT_BUFFER_FIELD $codec.av_encode.IN_LEFT_BUFFER_FIELD + 1;
   .CONST $codec.av_encode.MODE_FIELD $codec.av_encode.IN_RIGHT_BUFFER_FIELD + 1;

   .CONST $codec.av_encode.ENCODER_DATA_OBJECT_FIELD $codec.av_encode.MODE_FIELD + 1;
   .CONST $codec.av_encode.BUFFERING_THRESHOLD_FIELD $codec.av_encode.ENCODER_DATA_OBJECT_FIELD + 1;
   .CONST $codec.av_encode.STALL_COUNTER_FIELD $codec.av_encode.BUFFERING_THRESHOLD_FIELD + 1;

   .CONST $codec.av_encode.STRUC_SIZE $codec.av_encode.STALL_COUNTER_FIELD + 1;


   .CONST $codec.av_decode.ADDR_FIELD 0;
   .CONST $codec.av_decode.RESET_ADDR_FIELD $codec.av_decode.ADDR_FIELD + 1;
   .CONST $codec.av_decode.SILENCE_ADDR_FIELD $codec.av_decode.RESET_ADDR_FIELD + 1;

   .CONST $codec.av_decode.DECODER_STRUC_FIELD $codec.av_decode.SILENCE_ADDR_FIELD + 1;
   .CONST $codec.av_decode.IN_BUFFER_FIELD $codec.av_decode.DECODER_STRUC_FIELD;
   .CONST $codec.av_decode.OUT_LEFT_BUFFER_FIELD $codec.av_decode.IN_BUFFER_FIELD + 1;
   .CONST $codec.av_decode.OUT_RIGHT_BUFFER_FIELD $codec.av_decode.OUT_LEFT_BUFFER_FIELD + 1;
   .CONST $codec.av_decode.MODE_FIELD $codec.av_decode.OUT_RIGHT_BUFFER_FIELD + 1;
   .CONST $codec.av_decode.DECODER_NUM_OUTPUT_SAMPLES_FIELD $codec.av_decode.MODE_FIELD + 1;

   .CONST $codec.av_decode.DECODER_DATA_OBJECT_FIELD $codec.av_decode.DECODER_NUM_OUTPUT_SAMPLES_FIELD + 1;
   .CONST $codec.av_decode.TWS_CALLBACK_FIELD $codec.av_decode.DECODER_DATA_OBJECT_FIELD + 1;
   .CONST $codec.av_decode.DECODE_TO_STALL_THRESHOLD $codec.av_decode.TWS_CALLBACK_FIELD + 1;
    .CONST $codec.av_decode.STALL_TO_DECODE_THRESHOLD $codec.av_decode.DECODE_TO_STALL_THRESHOLD + 1;
   .CONST $codec.av_decode.STALL_BUFFER_LEVEL_FIELD $codec.av_decode.STALL_TO_DECODE_THRESHOLD + 1;
   .CONST $codec.av_decode.NORMAL_BUFFER_LEVEL_FIELD $codec.av_decode.STALL_BUFFER_LEVEL_FIELD + 1;
   .CONST $codec.av_decode.CODEC_PURGE_ENABLE_FIELD $codec.av_decode.NORMAL_BUFFER_LEVEL_FIELD + 1;
   .CONST $codec.av_decode.MASTER_RESET_FUNC_FIELD $codec.av_decode.CODEC_PURGE_ENABLE_FIELD + 1;

   .CONST $codec.av_decode.CODEC_PREV_WADDR_FIELD $codec.av_decode.MASTER_RESET_FUNC_FIELD + 1;
   .CONST $codec.av_decode.PAUSE_TIMER_FIELD $codec.av_decode.CODEC_PREV_WADDR_FIELD + 1;
   .CONST $codec.av_decode.CURRENT_RUNNING_MODE_FIELD $codec.av_decode.PAUSE_TIMER_FIELD + 1;
   .CONST $codec.av_decode.CAN_SWITCH_FIELD $codec.av_decode.CURRENT_RUNNING_MODE_FIELD + 1;
   .CONST $codec.av_decode.PREV_TIME_FIELD $codec.av_decode.CAN_SWITCH_FIELD + 1;
   .CONST $codec.av_decode.STALL_TIMER_FIELD $codec.av_decode.PREV_TIME_FIELD + 1;


   .CONST $codec.av_decode.STRUC_SIZE $codec.av_decode.STALL_TIMER_FIELD + 1;

   .CONST $codec.av_decode.PAUSE_TO_CLEAR_THRESHOLD 150;
   .CONST $codec.av_encode.STALL_THRESHOLD 10;

   .CONST $codec.pre_post_proc.PRE_PROC_FUNC_ADDR_FIELD 0;
   .CONST $codec.pre_post_proc.PRE_PROC_FUNC_DATA1_FIELD 1;
   .CONST $codec.pre_post_proc.PRE_PROC_FUNC_DATA2_FIELD 2;
   .CONST $codec.pre_post_proc.POST_PROC_FUNC_ADDR_FIELD 3;
   .CONST $codec.pre_post_proc.POST_PROC_FUNC_DATA1_FIELD 4;
   .CONST $codec.pre_post_proc.POST_PROC_FUNC_DATA2_FIELD 5;
   .CONST $codec.pre_post_proc.STRUC_SIZE 6;

   .CONST $codec.stream_encode.mux.NEXT_SINK_HANDLER_FIELD 0;
   .CONST $codec.stream_encode.mux.STATE_FIELD 1;
   .CONST $codec.stream_encode.mux.PREV_READ_PNTR_FIELD 2;
   .CONST $codec.stream_encode.mux.AMOUNT_LEFT_TO_DISCARD_FIELD 3;
   .CONST $codec.stream_encode.mux.TERMINAL_FIELD 4;
   .CONST $codec.stream_encode.mux.PORT_FIELD 5;
   .CONST $codec.stream_encode.mux.BYTE_ALIGNMENT_FIELD 6;
   .CONST $codec.stream_encode.mux.CBUFFER_STRUC_FIELD 7;
   .CONST $codec.stream_encode.mux.STRUC_SIZE $codec.stream_encode.mux.CBUFFER_STRUC_FIELD + $cbuffer.STRUC_SIZE;
.linefile 14 "vcp_8k_wired_to_24k_wired/sco.asm" 2

.linefile 1 "C:/ADK_CSR867x.WIN4.3.1.5/kalimba/lib_sets/sdk/include/frame_sync_tsksched.h" 1
.linefile 16 "vcp_8k_wired_to_24k_wired/sco.asm" 2

.linefile 1 "vcp_8k_wired_to_24k_wired/VCP.h" 1
.linefile 18 "vcp_8k_wired_to_24k_wired/sco.asm" 2
.linefile 1 "vcp_8k_wired_to_24k_wired/ports.h" 1
.linefile 11 "vcp_8k_wired_to_24k_wired/ports.h"
.CONST $CHAN_A_8KHZ_IN_PORT_NUMBER 0;
.CONST $CHAN_A_8KHZ_OUT_PORT_NUMBER 0;
.CONST $CHAN_A_24KHZ_IN_PORT_NUMBER 1;
.CONST $CHAN_A_24KHZ_OUT_PORT_NUMBER 1;


.CONST $CHAN_B_8KHZ_IN_PORT_NUMBER 2;
.CONST $CHAN_B_8KHZ_OUT_PORT_NUMBER 2;
.CONST $CHAN_B_24KHZ_IN_PORT_NUMBER 3;
.CONST $CHAN_B_24KHZ_OUT_PORT_NUMBER 3;


.CONST $CHAN_C_8KHZ_IN_PORT_NUMBER 4;
.CONST $CHAN_C_8KHZ_OUT_PORT_NUMBER 4;
.CONST $CHAN_C_24KHZ_IN_PORT_NUMBER 5;
.CONST $CHAN_C_24KHZ_OUT_PORT_NUMBER 5;
.linefile 19 "vcp_8k_wired_to_24k_wired/sco.asm" 2


.CONST $SCO_IN_PORT (($cbuffer.READ_PORT_MASK + $CHAN_B_8KHZ_IN_PORT_NUMBER) | $cbuffer.FORCE_PCM_AUDIO);
.CONST $SCO_OUT_PORT (($cbuffer.WRITE_PORT_MASK + $CHAN_B_8KHZ_OUT_PORT_NUMBER) | $cbuffer.FORCE_PCM_AUDIO);


.MODULE $sco_data;
    .DATASEGMENT DM;

    .VAR/DMCIRC mem1[3*93]; .VAR port_in.cbuffer_struc[$cbuffer.STRUC_SIZE] = LENGTH(mem1), &mem1, &mem1;
    .VAR/DMCIRC mem2[3*90]; .VAR sco_in.cbuffer_struc[$cbuffer.STRUC_SIZE] = LENGTH(mem2), &mem2, &mem2;
    .VAR/DMCIRC mem3[3*90]; .VAR port_out.cbuffer_struc[$cbuffer.STRUC_SIZE] = LENGTH(mem3), &mem3, &mem3;


    .VAR/DM sco_decoder[$sco_decoder.STRUC_SIZE] =
            $frame_sync.sco_decoder.pcm.validate,
            $frame_sync.sco_decoder.pcm.process,
            $frame_sync.sco_decoder.pcm.initialize,
            0,
            0.3;


   .VAR/DM1 buffer_speech[$plc100.SP_BUF_LEN_NB];
   .VAR/DM buffer_ola[$plc100.OLA_LEN_NB];


    .VAR/DM plc_obj[$plc100.STRUC_SIZE] =
                   &buffer_speech,
                   &buffer_speech,
                   &buffer_ola,
                   &sco_in.cbuffer_struc,
                   &$plc100.nb_consts,
                   $plc100.INITIAL_ATTENUATION,
                   0.3,
                   0 ...;

    .VAR/DM object[$sco_pkt_handler.STRUC_SIZE ] =
                   $SCO_IN_PORT | $cbuffer.FORCE_LITTLE_ENDIAN,
                   $SCO_IN_PORT | $cbuffer.FORCE_PCM_AUDIO,
                   &port_in.cbuffer_struc,
                   &sco_in.cbuffer_struc,

                   0x2000,
                   0x2000,





                   0,
                   0,
                   0,
                   &sco_decoder,

                   $plc100.process,
                   $plc100.initialize,




                   0,
                   0,
                   0,
                   0,
                   0,

                   &plc_obj,



                   $SCO_OUT_PORT | $cbuffer.FORCE_PCM_AUDIO,
                   -8,
                   &port_out.cbuffer_struc,
                   30,
                   0,
                   0,
                   0,
                   0,
                   0,
                   120,
                   30,
                   0,
                   0;

.ENDMODULE;
